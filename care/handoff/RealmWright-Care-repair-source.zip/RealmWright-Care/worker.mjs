var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/lib/cookies.js
function parseCookies(request) {
  const header = request.headers.get("Cookie") || "";
  const out = {};
  for (const part of header.split(";")) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const name = trimmed.slice(0, eq);
    const value = trimmed.slice(eq + 1);
    try {
      out[name] = decodeURIComponent(value);
    } catch {
    }
  }
  return out;
}
__name(parseCookies, "parseCookies");
function serializeCookie(name, value, { maxAgeSeconds, path = "/", secure = true, sameSite = "Lax", httpOnly = true } = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${path}`, `SameSite=${sameSite}`];
  if (httpOnly) parts.push("HttpOnly");
  if (secure) parts.push("Secure");
  if (typeof maxAgeSeconds === "number") parts.push(`Max-Age=${maxAgeSeconds}`);
  return parts.join("; ");
}
__name(serializeCookie, "serializeCookie");
function clearCookie(name, { path = "/", secure = true } = {}) {
  return serializeCookie(name, "", { path, secure, maxAgeSeconds: 0 });
}
__name(clearCookie, "clearCookie");

// src/lib/auth.js
var SESSION_TTL_SECONDS = 90 * 24 * 60 * 60;
var SESSION_COOKIE = "rw_care_session";
var RECOVERY_CODE_LENGTH = 24;
var CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
var AUTH_LIMITS = {
  bootstrap: { windowSeconds: 60 * 60, max: 20 },
  recovery: { windowSeconds: 60 * 60, max: 10 },
  owner: { windowSeconds: 60 * 60, max: 5 }
};
function isSecureEnv(env) {
  return env.ENVIRONMENT !== "development";
}
__name(isSecureEnv, "isSecureEnv");
function sessionCookieName(env) {
  return env.SESSION_COOKIE_NAME || SESSION_COOKIE;
}
__name(sessionCookieName, "sessionCookieName");
function jsonBody(data, status = 200, extraHeaders = {}) {
  const headers = new Headers({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  for (const [name, value] of new Headers(extraHeaders).entries()) {
    headers.set(name, value);
  }
  return new Response(JSON.stringify(data), {
    status,
    headers
  });
}
__name(jsonBody, "jsonBody");
function jsonError(status, message) {
  return jsonBody({ error: message }, status);
}
__name(jsonError, "jsonError");
function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}
__name(randomBytes, "randomBytes");
function bytesToHex(bytes) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
__name(bytesToHex, "bytesToHex");
function randomLocalSub() {
  return "local_" + bytesToHex(randomBytes(16));
}
__name(randomLocalSub, "randomLocalSub");
function randomToken() {
  const bytes = randomBytes(32);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
__name(randomToken, "randomToken");
async function hmacHex(secret, value) {
  if (typeof secret !== "string" || !secret) throw new Error("SESSION_SECRET is not configured");
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return bytesToHex(new Uint8Array(sig));
}
__name(hmacHex, "hmacHex");
function normalizeRecoveryCode(raw) {
  return typeof raw === "string" ? raw.toUpperCase().replace(/[\s-]/g, "") : "";
}
__name(normalizeRecoveryCode, "normalizeRecoveryCode");
function formatRecoveryCode(raw) {
  return raw.match(/.{1,4}/g).join("-");
}
__name(formatRecoveryCode, "formatRecoveryCode");
function randomRecoveryCode() {
  const bytes = randomBytes(RECOVERY_CODE_LENGTH);
  let code = "";
  for (const b of bytes) code += CROCKFORD[b % CROCKFORD.length];
  return code;
}
__name(randomRecoveryCode, "randomRecoveryCode");
function sanitizeReturnPath(raw) {
  if (typeof raw !== "string" || !raw.startsWith("/") || raw.startsWith("//") || raw.includes("://") || raw.includes("\\")) {
    return "/";
  }
  return raw;
}
__name(sanitizeReturnPath, "sanitizeReturnPath");
function isAction(request, expected) {
  return request.headers.get("X-Care-Action") === expected;
}
__name(isAction, "isAction");
function clientFingerprint(request) {
  return request.headers.get("CF-Connecting-IP") || "local-dev";
}
__name(clientFingerprint, "clientFingerprint");
async function checkAuthRateLimit(request, env, kind) {
  const cfg = AUTH_LIMITS[kind];
  if (!cfg) return true;
  const now = Math.floor(Date.now() / 1e3);
  const bucket = Math.floor(now / cfg.windowSeconds);
  const fingerprint = await hmacHex(env.SESSION_SECRET, clientFingerprint(request));
  const row = await env.DB.prepare(
    "SELECT count FROM care_auth_attempts WHERE kind = ?1 AND fingerprint = ?2 AND bucket = ?3"
  ).bind(kind, fingerprint, bucket).first();
  if ((row?.count || 0) >= cfg.max) return false;
  await env.DB.prepare(
    `INSERT INTO care_auth_attempts (kind, fingerprint, bucket, count)
     VALUES (?1, ?2, ?3, 1)
     ON CONFLICT(kind, fingerprint, bucket) DO UPDATE SET count = count + 1`
  ).bind(kind, fingerprint, bucket).run();
  return true;
}
__name(checkAuthRateLimit, "checkAuthRateLimit");
function setSessionCookie(headers, token, env) {
  headers.append(
    "Set-Cookie",
    serializeCookie(sessionCookieName(env), token, {
      maxAgeSeconds: SESSION_TTL_SECONDS,
      path: "/",
      secure: isSecureEnv(env),
      sameSite: "Lax"
    })
  );
}
__name(setSessionCookie, "setSessionCookie");
async function createLocalUser(env, { name = "A GM", isOwner = false } = {}) {
  const sub = randomLocalSub();
  const now = Math.floor(Date.now() / 1e3);
  await env.DB.prepare(
    `INSERT INTO users
      (sub, name, avatar_url, email, created_at, last_seen, auth_provider, is_owner)
     VALUES (?1, ?2, NULL, NULL, ?3, ?3, 'local', ?4)`
  ).bind(sub, name, now, isOwner ? 1 : 0).run();
  return { sub, name, avatar: null, isOwner };
}
__name(createLocalUser, "createLocalUser");
async function createSession(env, sub) {
  const token = randomToken();
  const tokenHash = await hmacHex(env.SESSION_SECRET, token);
  const now = Math.floor(Date.now() / 1e3);
  await env.DB.prepare(
    `INSERT INTO care_sessions
      (token_hash, user_sub, created_at, last_seen, expires_at, revoked_at)
     VALUES (?1, ?2, ?3, ?3, ?4, NULL)`
  ).bind(tokenHash, sub, now, now + SESSION_TTL_SECONDS).run();
  return token;
}
__name(createSession, "createSession");
async function handleBootstrap(request, env) {
  if (!isAction(request, "bootstrap")) return jsonError(403, "Unsupported sign-in request.");
  if (await getSession(request, env)) return jsonBody({ ok: true, existing: true });
  if (!await checkAuthRateLimit(request, env, "bootstrap")) {
    return jsonError(429, "Too many new-device attempts. Try again later.");
  }
  try {
    const user = await createLocalUser(env);
    const token = await createSession(env, user.sub);
    const headers = new Headers();
    setSessionCookie(headers, token, env);
    return jsonBody({ ok: true, created: true }, 200, headers);
  } catch {
    return jsonError(500, "Could not create a Care identity. Try again shortly.");
  }
}
__name(handleBootstrap, "handleBootstrap");
async function handleIssueRecovery(request, env) {
  if (!isAction(request, "issue-recovery")) return jsonError(403, "Unsupported recovery request.");
  const session = await getSession(request, env);
  if (!session) return jsonError(401, "Start Care on this device before creating recovery details.");
  const code = randomRecoveryCode();
  const hash = await hmacHex(env.SESSION_SECRET, normalizeRecoveryCode(code));
  const now = Math.floor(Date.now() / 1e3);
  await env.DB.prepare(
    "UPDATE users SET recovery_hash = ?1, recovery_issued_at = ?2 WHERE sub = ?3 AND auth_provider = 'local'"
  ).bind(hash, now, session.sub).run();
  return jsonBody({ ok: true, recoveryCode: formatRecoveryCode(code) });
}
__name(handleIssueRecovery, "handleIssueRecovery");
async function handleRecover(request, env) {
  if (!isAction(request, "recover")) return jsonError(403, "Unsupported recovery request.");
  if (!await checkAuthRateLimit(request, env, "recovery")) {
    return jsonError(429, "Too many recovery attempts. Try again later.");
  }
  let body;
  try {
    body = await readCareJson(request);
  } catch {
    return jsonError(400, "Malformed recovery request.");
  }
  const code = normalizeRecoveryCode(body?.code);
  if (code.length !== RECOVERY_CODE_LENGTH || !/^[0-9A-HJKMNP-TV-Z]+$/.test(code)) {
    return jsonError(400, "Enter the recovery code exactly as shown.");
  }
  const hash = await hmacHex(env.SESSION_SECRET, code);
  const user = await env.DB.prepare(
    `SELECT sub, name, avatar_url, is_owner
     FROM users WHERE recovery_hash = ?1 AND auth_provider = 'local' LIMIT 1`
  ).bind(hash).first();
  if (!user) return jsonError(401, "That recovery code is invalid or already used.");
  const cleared = await env.DB.prepare(
    `UPDATE users SET recovery_hash = NULL, recovery_issued_at = NULL
     WHERE sub = ?1 AND recovery_hash = ?2`
  ).bind(user.sub, hash).run();
  if (!cleared.meta || cleared.meta.changes !== 1) {
    return jsonError(401, "That recovery code is invalid or already used.");
  }
  try {
    const token = await createSession(env, user.sub);
    const headers = new Headers();
    setSessionCookie(headers, token, env);
    return jsonBody({ ok: true, name: user.name, isOwner: user.is_owner === 1 }, 200, headers);
  } catch {
    return jsonError(500, "Could not complete recovery. Try again shortly.");
  }
}
__name(handleRecover, "handleRecover");
async function handleOwnerClaim(request, env) {
  if (!isAction(request, "owner-claim")) return jsonError(403, "Unsupported owner setup request.");
  if (!await checkAuthRateLimit(request, env, "owner")) {
    return jsonError(429, "Too many owner setup attempts. Try again later.");
  }
  const setupToken = typeof env.OWNER_SETUP_TOKEN === "string" ? env.OWNER_SETUP_TOKEN : "";
  if (!setupToken) return jsonError(503, "Owner setup is not configured.");
  let body;
  try {
    body = await readCareJson(request);
  } catch {
    return jsonError(400, "Malformed owner setup request.");
  }
  const provided = typeof body?.token === "string" ? body.token : "";
  if (!provided || provided !== setupToken) return jsonError(401, "Owner setup token was not accepted.");
  if (await env.DB.prepare("SELECT sub FROM users WHERE is_owner = 1 LIMIT 1").first()) {
    return jsonError(409, "Owner setup has already been completed.");
  }
  try {
    const user = await createLocalUser(env, { name: "Owner", isOwner: true });
    const token = await createSession(env, user.sub);
    const headers = new Headers();
    setSessionCookie(headers, token, env);
    return jsonBody({ ok: true, owner: true }, 200, headers);
  } catch {
    return jsonError(409, "Owner setup has already been completed.");
  }
}
__name(handleOwnerClaim, "handleOwnerClaim");
function ownerSetupPage() {
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>RealmWright Care owner setup</title>
  <style>body{font:16px system-ui;max-width:32rem;margin:4rem auto;padding:1rem}
  input,button{font:inherit;padding:.7rem;width:100%;box-sizing:border-box}
  button{margin-top:.75rem;cursor:pointer}.error{color:#a20;margin-top:1rem}</style></head>
  <body><h1>Owner setup</h1>
  <p>This is a one-time setup page. Paste the Cloudflare owner setup token,
  then store your recovery code when Care provides it.</p>
  <form id="owner-form"><label>Setup token
  <input id="owner-token" type="password" autocomplete="off" required></label>
  <button>Claim Owner Desk</button><p id="owner-status" class="error" role="status"></p></form>
  <script>
  document.getElementById('owner-form').addEventListener('submit', async (e) => {
    e.preventDefault(); const out = document.getElementById('owner-status');
    const token = document.getElementById('owner-token').value;
    const res = await fetch('/auth/owner/claim', { method: 'POST',
      headers: {'Content-Type':'application/json','X-Care-Action':'owner-claim'},
      body: JSON.stringify({token}) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { out.textContent = data.error || 'Setup failed.'; return; }
    location.href = '/desk/';
  });
  <\/script></body></html>`;
  return new Response(html, { status: 200, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
}
__name(ownerSetupPage, "ownerSetupPage");
async function handleLogout(request, env, url) {
  const token = parseCookies(request)[sessionCookieName(env)];
  if (token) {
    const hash = await hmacHex(env.SESSION_SECRET, token);
    await env.DB.prepare("UPDATE care_sessions SET revoked_at = ?1 WHERE token_hash = ?2 AND revoked_at IS NULL")
      .bind(Math.floor(Date.now()/1000), hash).run();
  }
  const headers = new Headers({Location: sanitizeReturnPath(url.searchParams.get("return") || "/"), "Cache-Control":"no-store"});
  headers.append("Set-Cookie", clearCookie(sessionCookieName(env), {secure:isSecureEnv(env)}));
  return new Response(null,{status:302,headers});
}

__name(handleLogout, "handleLogout");
async function getSession(request, env) {
  try {
    const cookies = parseCookies(request);
    const token = cookies[sessionCookieName(env)];
    if (!token) return null;
    const tokenHash = await hmacHex(env.SESSION_SECRET, token);
    const now = Math.floor(Date.now() / 1e3);
    const row = await env.DB.prepare(
      `SELECT s.user_sub AS sub, u.name, u.avatar_url, u.is_owner, u.auth_provider
       FROM care_sessions s JOIN users u ON u.sub = s.user_sub
       WHERE s.token_hash = ?1 AND s.revoked_at IS NULL AND s.expires_at > ?2`
    ).bind(tokenHash, now).first();
    if (!row) return null;
    return {
      sub: row.sub,
      name: row.name || "A GM",
      avatar: row.avatar_url || null,
      isOwner: row.is_owner === 1,
      authProvider: row.auth_provider || "legacy-google"
    };
  } catch {
    return null;
  }
}
__name(getSession, "getSession");

// src/routes/auth.js
async function routeAuth(request, env, url) {
  if (request.method === "POST" && url.pathname === "/auth/bootstrap") {
    return handleBootstrap(request, env);
  }
  if (request.method === "POST" && url.pathname === "/auth/recovery") {
    return handleIssueRecovery(request, env);
  }
  if (request.method === "POST" && url.pathname === "/auth/recover") {
    return handleRecover(request, env);
  }
  if (request.method === "GET" && url.pathname === "/auth/owner") {
    return ownerSetupPage();
  }
  if (request.method === "POST" && url.pathname === "/auth/owner/claim") {
    return handleOwnerClaim(request, env);
  }
  if (request.method === "GET" && url.pathname === "/auth/logout") {
    return handleLogout(request, env, url);
  }
  return new Response("Not found", { status: 404 });
}
__name(routeAuth, "routeAuth");

// src/lib/http.js
function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...extraHeaders }
  });
}
__name(json, "json");
function jsonError2(status, message) {
  return json({ error: message }, status);
}
__name(jsonError2, "jsonError");
async function notFound(env) {
  const res = await env.ASSETS.fetch(new Request("https://internal/404.html"));
  const body = await res.text();
  return new Response(body, { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } });
}
__name(notFound, "notFound");
function isSameOrigin(request, url) {
  const origin = request.headers.get("Origin");
  if (!origin) {
    return true;
  }
  try {
    return new URL(origin).origin === url.origin;
  } catch {
    return false;
  }
}
__name(isSameOrigin, "isSameOrigin");

// src/lib/taxonomy.js
var cache = null;
async function loadTaxonomy(env) {
  if (cache) return cache;
  const res = await env.ASSETS.fetch(new Request("https://internal/data/taxonomy.json"));
  cache = await res.json();
  return cache;
}
__name(loadTaxonomy, "loadTaxonomy");
async function areaMap(env) {
  const tax = await loadTaxonomy(env);
  const map = new Map(tax.areas.map((a) => [a.key, a]));
  map.set(tax.ideaExtraTile.key, { ...tax.ideaExtraTile, parts: [] });
  return map;
}
__name(areaMap, "areaMap");
async function isValidArea(env, area) {
  const map = await areaMap(env);
  return map.has(area);
}
__name(isValidArea, "isValidArea");
async function isValidPart(env, area, part) {
  if (!part) return true;
  const map = await areaMap(env);
  const areaObj = map.get(area);
  if (!areaObj) return false;
  for (const p of areaObj.parts || []) {
    if (p.key === part) return true;
    if (p.children && p.children.some((c) => c.key === part)) return true;
  }
  return false;
}
__name(isValidPart, "isValidPart");
async function symptomsFor(env, area) {
  const tax = await loadTaxonomy(env);
  const areaSpecific = tax.symptomsByArea && tax.symptomsByArea[area] || [];
  return [...tax.symptomsUniversal, ...areaSpecific];
}
__name(symptomsFor, "symptomsFor");
async function isValidSymptom(env, area, symptom) {
  if (symptom == null || symptom === "") return true;
  if (typeof symptom !== "string") return false;
  const symptoms = await symptomsFor(env, area);
  return symptoms.some((s) => s.key === symptom);
}
__name(isValidSymptom, "isValidSymptom");
async function isValidSymptomDetail(env, area, symptom, detail) {
  if (detail == null || detail === "") return true;
  if (typeof detail !== "string") return false;
  const symptoms = await symptomsFor(env, area);
  const s = symptoms.find((x) => x.key === symptom);
  const followups = s && s.followups || [];
  return followups.some((f) => f.key === detail);
}
__name(isValidSymptomDetail, "isValidSymptomDetail");
async function isValidFrequency(env, frequency) {
  if (frequency == null || frequency === "") return true;
  if (typeof frequency !== "string") return false;
  const tax = await loadTaxonomy(env);
  return tax.frequency.some((f) => f.key === frequency);
}
__name(isValidFrequency, "isValidFrequency");
async function isValidIdeaKind(env, ideaKind) {
  if (ideaKind == null || ideaKind === "") return true;
  if (typeof ideaKind !== "string") return false;
  const tax = await loadTaxonomy(env);
  return tax.ideaKinds.some((k) => k.key === ideaKind);
}
__name(isValidIdeaKind, "isValidIdeaKind");
async function isValidImportance(env, importance) {
  if (importance == null || importance === "") return true;
  if (typeof importance !== "string") return false;
  const tax = await loadTaxonomy(env);
  return tax.importance.some((i) => i.key === importance);
}
__name(isValidImportance, "isValidImportance");

// src/lib/ratelimit.js
var REPORTS_PER_DAY = 5;
var REPORTS_PER_DAY_NEW_ACCOUNT = 2;
var NEW_ACCOUNT_WINDOW_SECONDS = 24 * 60 * 60;
var COMMENTS_PER_DAY = 30;
var VOTE_CHANGES_PER_DAY = 200;
function startOfUtcDaySeconds(nowSeconds) {
  const d = new Date(nowSeconds * 1e3);
  return Math.floor(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) / 1e3);
}
__name(startOfUtcDaySeconds, "startOfUtcDaySeconds");
async function checkReportLimit(env, userSub) {
  const now = Math.floor(Date.now() / 1e3);
  const dayStart = startOfUtcDaySeconds(now);
  const userRow = await env.DB.prepare("SELECT created_at FROM users WHERE sub = ?1").bind(userSub).first();
  const isNewAccount = userRow && now - userRow.created_at < NEW_ACCOUNT_WINDOW_SECONDS;
  const limit = isNewAccount ? REPORTS_PER_DAY_NEW_ACCOUNT : REPORTS_PER_DAY;
  const { count } = await env.DB.prepare(
    "SELECT COUNT(*) as count FROM reports WHERE user_sub = ?1 AND created_at >= ?2"
  ).bind(userSub, dayStart).first();
  if (count >= limit) {
    return {
      allowed: false,
      message: `You've filed ${limit} reports today \u2014 the board opens again at midnight UTC.`
    };
  }
  return { allowed: true };
}
__name(checkReportLimit, "checkReportLimit");
async function checkCommentLimit(env, userSub) {
  const dayStart = startOfUtcDaySeconds(Math.floor(Date.now() / 1e3));
  const { count } = await env.DB.prepare(
    "SELECT COUNT(*) as count FROM comments WHERE user_sub = ?1 AND created_at >= ?2"
  ).bind(userSub, dayStart).first();
  if (count >= COMMENTS_PER_DAY) {
    return {
      allowed: false,
      message: `You've posted ${COMMENTS_PER_DAY} comments today \u2014 the board opens again at midnight UTC.`
    };
  }
  return { allowed: true };
}
__name(checkCommentLimit, "checkCommentLimit");
async function checkVoteLimit(env, userSub) {
  const dayStart = startOfUtcDaySeconds(Math.floor(Date.now() / 1e3));
  const { count } = await env.DB.prepare(
    "SELECT COUNT(*) as count FROM vote_events WHERE user_sub = ?1 AND created_at >= ?2"
  ).bind(userSub, dayStart).first();
  if (count >= VOTE_CHANGES_PER_DAY) {
    return {
      allowed: false,
      message: `You've changed ${VOTE_CHANGES_PER_DAY} votes today \u2014 the board opens again at midnight UTC.`
    };
  }
  return { allowed: true };
}
__name(checkVoteLimit, "checkVoteLimit");

// src/data/blocklist.json
var blocklist_default = {
  note: "Compact content-check list (design \xA73.4 \u2014 'kept minimal on purpose'). A match sets held=1: never auto-rejected, just queued in the Owner Desk for a human look. This seed list proves the mechanism end-to-end with uncontroversial spam examples. Hunter: add real slur/abuse terms to `phrases` before real launch \u2014 plain lowercase words/phrases, one edit, no code change needed. Kept out of this build deliberately rather than fabricated.",
  phrases: [
    "buy followers",
    "forex signals",
    "crypto giveaway",
    "click this link now",
    "work from home guaranteed",
    "act now limited time offer",
    "free followers instantly",
    "seo backlinks cheap",
    "nudes",
    "onlyfans"
  ],
  patterns: [
    "(https?:\\/\\/[^\\s]+){3,}",
    "(.)\\1{9,}"
  ]
};

// src/lib/blocklist.js
function normalize(text) {
  return (text || "").toLowerCase().replace(/\s+/g, " ").trim();
}
__name(normalize, "normalize");
async function isHeld(env, text) {
  if (!text) return false;
  const normalized = normalize(text);
  for (const phrase of blocklist_default.phrases || []) {
    if (normalized.includes(phrase.toLowerCase())) return true;
  }
  for (const patternSrc of blocklist_default.patterns || []) {
    try {
      if (new RegExp(patternSrc, "i").test(text)) return true;
    } catch {
    }
  }
  return false;
}
__name(isHeld, "isHeld");

// src/lib/votes.js
async function buildVoteStatements(env, itemId, userSub, newValue) {
  if (![1,-1,0].includes(newValue)) throw new Error("invalid vote value");
  const now = Math.floor(Date.now()/1000);
  const statements = [env.DB.prepare(`INSERT INTO vote_events (item_id,user_sub,value,created_at)
    SELECT ?1,?2,?3,?4 WHERE COALESCE((SELECT value FROM votes WHERE item_id=?1 AND user_sub=?2),0) != ?3`)
    .bind(itemId,userSub,newValue,now)];
  statements.push(newValue===0
    ? env.DB.prepare("DELETE FROM votes WHERE item_id=?1 AND user_sub=?2").bind(itemId,userSub)
    : env.DB.prepare(`INSERT INTO votes (item_id,user_sub,value,created_at) VALUES (?1,?2,?3,?4)
      ON CONFLICT(item_id,user_sub) DO UPDATE SET value=excluded.value,created_at=excluded.created_at WHERE votes.value != excluded.value`)
      .bind(itemId,userSub,newValue,now));
  statements.push(env.DB.prepare(`UPDATE items SET
    agree_count=(SELECT COUNT(*) FROM votes WHERE item_id=?1 AND value=1),
    disagree_count=(SELECT COUNT(*) FROM votes WHERE item_id=?1 AND value=-1) WHERE id=?1`).bind(itemId));
  return {statements,changed:true};
}

__name(buildVoteStatements, "buildVoteStatements");
async function castVote(env,itemId,userSub,newValue) {
  const {statements}=await buildVoteStatements(env,itemId,userSub,newValue);
  statements.push(env.DB.prepare("SELECT net,agree_count,disagree_count FROM items WHERE id=?1").bind(itemId));
  const results=await env.DB.batch(statements);
  const row=results[results.length-1].results?.[0] || {};
  return {changed:(results[0].meta?.changes || 0)>0,net:row.net,agreeCount:row.agree_count,disagreeCount:row.disagree_count,value:newValue};
}

__name(castVote, "castVote");

// src/lib/titles.js
var SYMPTOM_SHORT = {
  nothing_happened: "didn't respond to a click",
  wrong_thing: "did the wrong thing",
  work_disappeared: "work didn't save",
  display_broken: "display looks broken",
  froze_crashed: "froze or crashed",
  slow: "running slow",
  error_message: "showed an error",
  something_else: "something felt off",
  ai_wrong_answer: "AI gave a bad answer",
  ai_call_failed: "AI call failed",
  wont_import: "file wouldn't import",
  pdf_missing_content: "PDF missing content",
  license_wont_activate: "license won't activate"
};
var FREQUENCY_LABEL = { every_time: "every time", sometimes: "sometimes", once: "once" };
function composeTitle({ type, areaLabel, symptom, frequency, ask }) {
  if (type === "bug") {
    const symptomText = SYMPTOM_SHORT[symptom] || "something went wrong";
    const freqText = FREQUENCY_LABEL[frequency];
    return freqText ? `${areaLabel} \u2014 ${symptomText} (${freqText})` : `${areaLabel} \u2014 ${symptomText}`;
  }
  const askTrimmed = (ask || "").trim();
  if (askTrimmed) {
    const short = askTrimmed.length > 70 ? `${askTrimmed.slice(0, 67)}\u2026` : askTrimmed;
    return `${areaLabel} \u2014 ${short}`;
  }
  return `${areaLabel} \u2014 new idea`;
}
__name(composeTitle, "composeTitle");

// src/lib/followup.js
function detectGaps(payload) {
  const gaps = [];
  const area = payload.area;
  const part = payload.part;
  const vaguePart = !part || part === "not-sure" || part === "other";
  if (area === "exports-data" && vaguePart) {
    gaps.push({
      q: "which_export",
      prompt: "Which export was it?",
      options: [
        { key: "story_bible_pdf", label: "Story Bible PDF" },
        { key: "session_prep_pdf", label: "Session Prep PDF" },
        { key: "foundry", label: "Foundry VTT" },
        { key: "json", label: "JSON" },
        { key: "dont_know", label: "Don\u2019t know" }
      ]
    });
  }
  if (area === "ai" && (payload.part === "generator" || vaguePart)) {
    gaps.push({
      q: "which_generator",
      prompt: "Which generator was involved?",
      options: [
        { key: "session_prep", label: "Session Prep" },
        { key: "strong_start", label: "Strong Start" },
        { key: "encounter", label: "Encounter" },
        { key: "names", label: "Names" },
        { key: "other", label: "Another one" },
        { key: "dont_know", label: "Don\u2019t know" }
      ]
    });
  }
  if (area === "license-setup" && payload.symptom === "license_wont_activate") {
    gaps.push({
      q: "license_step",
      prompt: "Where did activation stop?",
      options: [
        { key: "entering_key", label: "Entering the key" },
        { key: "after_entering", label: "Right after I entered it" },
        { key: "never_prompted", label: "It never asked me" },
        { key: "dont_know", label: "Not sure" }
      ]
    });
  }
  if (payload.type === "bug" && !payload.expected && !payload.actual && !payload.freetext && payload.symptom && payload.symptom !== "work_disappeared") {
    gaps.push({
      q: "when_moment",
      prompt: "When did it happen?",
      options: [
        { key: "right_away", label: "Right when I opened it" },
        { key: "mid_task", label: "In the middle of working" },
        { key: "on_save_export", label: "When saving or exporting" },
        { key: "random", label: "Seemed random" }
      ]
    });
  }
  if (payload.type === "idea" && !payload.why) {
    gaps.push({
      q: "idea_payoff",
      prompt: "What would this help with most?",
      options: [
        { key: "save_time", label: "Saving prep time" },
        { key: "at_the_table", label: "Running the table live" },
        { key: "organize", label: "Keeping my world organized" },
        { key: "quality", label: "Better-quality results" }
      ]
    });
  }
  return gaps;
}
__name(detectGaps, "detectGaps");
async function buildFollowupQuestion(env, payload, alreadyAsked, runText2) {
  if (env.FEATURE_MICRO_INTERVIEW !== "true") return { question: null };
  if ((alreadyAsked || []).length >= 2) return { question: null };
  const gaps = detectGaps(payload).filter((g) => !alreadyAsked.includes(g.q));
  if (gaps.length === 0) return { question: null };
  const gap = gaps[0];
  if (runText2) {
    try {
      const phrased = await runText2(
        env,
        `Rewrite this one short question to sound warm and natural for a tabletop game master, 12 words max, no preamble, keep the meaning exactly: "${gap.prompt}"`,
        { system: "You rephrase a single UI question. Output only the rewritten question, nothing else.", maxTokens: 40 }
      );
      if (phrased && phrased.length <= 120) {
        gap.prompt = phrased.replace(/^["']|["']$/g, "").trim();
      }
    } catch {
    }
  }
  return { question: gap };
}
__name(buildFollowupQuestion, "buildFollowupQuestion");

// src/lib/ai.js
var DEFAULT_MODEL = "@cf/meta/llama-3.1-8b-instruct";
var OPENROUTER_MODEL = "meta-llama/llama-3.1-8b-instruct";
var TIMEOUT_MS = 8e3;
function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error("ai timeout")), ms))
  ]);
}
__name(withTimeout, "withTimeout");
async function runText(env, prompt, { system = "", maxTokens = 400 } = {}) {
  if (env.AI && typeof env.AI.run === "function") {
    try {
      const model = env.AI_TEXT_MODEL || DEFAULT_MODEL;
      const messages = [];
      if (system) messages.push({ role: "system", content: system });
      messages.push({ role: "user", content: prompt });
      const res = await withTimeout(env.AI.run(model, { messages, max_tokens: maxTokens }), TIMEOUT_MS);
      const text = res && (res.response || res.result || res.choices && res.choices[0]?.message?.content);
      if (text && String(text).trim()) return String(text).trim();
    } catch {
    }
  }
  if (env.OPENROUTER_KEY) {
    try {
      const res = await withTimeout(
        fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${env.OPENROUTER_KEY}` },
          body: JSON.stringify({
            model: env.OPENROUTER_MODEL || OPENROUTER_MODEL,
            messages: [
              ...system ? [{ role: "system", content: system }] : [],
              { role: "user", content: prompt }
            ],
            max_tokens: maxTokens
          })
        }),
        TIMEOUT_MS
      );
      if (res.ok) {
        const body = await res.json();
        const text = body.choices?.[0]?.message?.content;
        if (text && text.trim()) return text.trim();
      }
    } catch {
    }
  }
  return null;
}
__name(runText, "runText");

// src/routes/report.js
var ONE_LINE_MAX = 300;
var TEXTAREA_MAX = 2e3;
function clip(str, max) {
  if (typeof str !== "string") return "";
  const trimmed = str.trim();
  return trimmed.length > max ? trimmed.slice(0, max) : trimmed;
}
__name(clip, "clip");
function allFreeText(body) {
  return [body.expected, body.actual, body.freetext, body.ask, body.why, body.doneLooksLike].filter(Boolean).join("\n");
}
__name(allFreeText, "allFreeText");
function buildContract(body) {
  const ctx = body.ctx && typeof body.ctx === "object" ? body.ctx : {};
  const clientCtx = body.clientCtx && typeof body.clientCtx === "object" ? body.clientCtx : {};
  const contract = {
    type: body.type,
    area: body.area,
    part: body.part || null,
    symptom: body.type === "bug" ? body.symptom || null : null,
    symptom_detail: body.type === "bug" ? body.symptomDetail || null : null,
    frequency: body.type === "bug" ? body.frequency || null : null,
    expected: body.type === "bug" ? clip(body.expected, ONE_LINE_MAX) : null,
    actual: body.type === "bug" ? clip(body.actual, ONE_LINE_MAX) : null,
    freetext: body.type === "bug" ? clip(body.freetext, TEXTAREA_MAX) : "",
    importance: body.type === "idea" ? body.importance || null : null,
    ctx: {
      v: careContext(ctx.v),
      schema: careContext(ctx.schema),
      build: careContext(ctx.build),
      mode: careContext(ctx.mode),
      theme: careContext(ctx.theme),
      ai: careContext(ctx.ai),
      os: careContext(clientCtx.os,80),
      browser: careContext(clientCtx.browser,80),
      screen: careContext(clientCtx.screen,80),
      lang: careContext(clientCtx.lang,80)
    },
    followups: []
  };
  if (body.type === "idea") {
    contract.ideaKind = body.ideaKind || null;
    contract.ask = clip(body.ask, ONE_LINE_MAX);
    contract.why = clip(body.why, ONE_LINE_MAX);
    contract.doneLooksLike = clip(body.doneLooksLike, ONE_LINE_MAX);
  }
  return contract;
}
__name(buildContract, "buildContract");
async function handlePostReport(request, env, url) {
  const session = await getSession(request, env);
  if (!session) return jsonError2(401, "Sign in to send a report.");
  const user = await env.DB.prepare("SELECT banned FROM users WHERE sub = ?1").bind(session.sub).first();
  if (user && user.banned) return jsonError2(403, "This account can no longer post to the board.");
  let body;
  try {
    body = await readCareJson(request);
  } catch {
    return jsonError2(400, "Malformed request body.");
  }
  if (!["bug", "idea"].includes(body.type)) return jsonError2(400, 'type must be "bug" or "idea".');
  if (!await isValidArea(env, body.area)) return jsonError2(400, "That area isn't recognized.");
  if (!await isValidPart(env, body.area, body.part)) return jsonError2(400, "That part isn't recognized for this area.");
  if (body.type === "bug") {
    if (!await isValidSymptom(env, body.area, body.symptom)) return jsonError2(400, "That symptom isn't recognized.");
    if (!await isValidSymptomDetail(env, body.area, body.symptom, body.symptomDetail)) return jsonError2(400, "That symptom detail isn't recognized.");
    if (!await isValidFrequency(env, body.frequency)) return jsonError2(400, "That frequency isn't recognized.");
  } else {
    if (!await isValidIdeaKind(env, body.ideaKind)) return jsonError2(400, "That idea type isn't recognized.");
    if (!await isValidImportance(env, body.importance)) return jsonError2(400, "That importance isn't recognized.");
  }
  const mode = body.mode === "join" ? "join" : "create";
  if (mode === "join" && !Number.isInteger(body.joinItemId)) {
    return jsonError2(400, "joinItemId is required to join an existing report.");
  }
  const limitCheck = await checkReportLimit(env, session.sub);
  if (!limitCheck.allowed) return jsonError2(429, limitCheck.message);
  const contract = buildContract(body);
  const now = Math.floor(Date.now() / 1e3);
  const combinedText = [clip(body.title, ONE_LINE_MAX), allFreeText(contract)].join("\n");
  const textIsHeld = combinedText ? await isHeld(env, combinedText) : false;
  if (mode === "join") {
    const item = await env.DB.prepare("SELECT id, type, area, merged_into, held FROM items WHERE id = ?1").bind(body.joinItemId).first();
    if (!item || item.held) return jsonError2(404, "That report doesn't exist.");
    if (item.merged_into) {
      return json({ error: "That report was merged into another one.", mergedInto: item.merged_into }, 409);
    }
    if (item.type !== body.type || item.area !== body.area) return jsonError2(400, "Choose a matching report in the same area.");
    const reportInsert2 = env.DB.prepare(
      "INSERT INTO reports (item_id, user_sub, payload, created_at, held) VALUES (?1, ?2, ?3, ?4, ?5) RETURNING id"
    ).bind(item.id, session.sub, JSON.stringify(contract), now, textIsHeld ? 1 : 0);
    const batch = [reportInsert2];
    if (!textIsHeld) {
      const { statements: voteStatements2 } = await buildVoteStatements(env, item.id, session.sub, 1);
      batch.push(
        env.DB.prepare("UPDATE items SET reports_count = reports_count + 1 WHERE id = ?1").bind(item.id),
        ...voteStatements2
      );
    }
    const saved = await env.DB.batch(batch);
    const reportIdRow2 = saved[0].results?.[0];
    return json({ ok: true, itemId: item.id, reportId: reportIdRow2?.id ?? null, joined: true, held: !!textIsHeld });
  }
  const taxonomy = await loadTaxonomy(env);
  const areaObj = taxonomy.areas.find((a) => a.key === body.area) || (taxonomy.ideaExtraTile.key === body.area ? taxonomy.ideaExtraTile : null);
  const areaLabel = areaObj ? areaObj.label : body.area;
  const title = clip(body.title, ONE_LINE_MAX) || composeTitle({
    type: body.type,
    areaLabel,
    symptom: contract.symptom,
    frequency: contract.frequency,
    ask: contract.ask
  });
  // One transaction: a failed report cannot leave an empty public item.
  const itemInsert = env.DB.prepare(`INSERT INTO items (type,area,part,title,status,created_at,created_by,held)
    VALUES (?1,?2,?3,?4,'open',?5,?6,?7) RETURNING id`)
    .bind(body.type,body.area,body.part||null,title,now,session.sub,textIsHeld?1:0);
  const reportInsert=env.DB.prepare(`INSERT INTO reports (item_id,user_sub,payload,created_at,held)
    VALUES (last_insert_rowid(),?1,?2,?3,0) RETURNING id,item_id`)
    .bind(session.sub,JSON.stringify(contract),now);
  const latest="(SELECT item_id FROM reports WHERE user_sub=?1 ORDER BY id DESC LIMIT 1)";
  const batch=[itemInsert,reportInsert,
    env.DB.prepare(`UPDATE items SET reports_count=1 WHERE id=${latest}`).bind(session.sub)];
  if (!textIsHeld) {
    batch.push(env.DB.prepare(`INSERT INTO votes (item_id,user_sub,value,created_at) VALUES (${latest},?1,1,?2)`).bind(session.sub,now),
      env.DB.prepare(`INSERT INTO vote_events (item_id,user_sub,value,created_at) VALUES (${latest},?1,1,?2)`).bind(session.sub,now),
      env.DB.prepare(`UPDATE items SET agree_count=1 WHERE id=${latest}`).bind(session.sub));
  }
  const saved=await env.DB.batch(batch);
  const itemId=saved[0].results[0].id, reportId=saved[1].results[0].id;
  return json({ok:true,itemId,reportId,title,held:!!textIsHeld});
}
__name(handlePostReport, "handlePostReport");
async function handlePatchFollowup(request, env, url, reportId) {
  const session = await getSession(request, env);
  if (!session) return jsonError2(401, "Sign in required.");
  const user = await env.DB.prepare("SELECT banned FROM users WHERE sub = ?1").bind(session.sub).first();
  if (user && user.banned) return jsonError2(403, "This account can no longer post to the board.");
  const report = await env.DB.prepare("SELECT id, user_sub, payload FROM reports WHERE id = ?1").bind(reportId).first();
  if (!report) return jsonError2(404, "Report not found.");
  if (report.user_sub !== session.sub) return jsonError2(403, "Only the reporter can answer this.");
  let body;
  try {
    body = await readCareJson(request);
  } catch {
    return jsonError2(400, "Malformed request body.");
  }
  if (typeof body.q !== "string" || typeof body.a !== "string") {
    return jsonError2(400, "Expected { q, a }.");
  }
  const payload = JSON.parse(report.payload);
  payload.followups = Array.isArray(payload.followups) ? payload.followups : [];
  const same=payload.followups.find(f=>f.q===body.q);
  if (same) return same.a===body.a ? json({ok:true}) : jsonError2(409,"This question already has an answer.");
  if (payload.followups.length >= 2) return jsonError2(400,"This report already has its follow-up answers.");
  const question=detectGaps(payload).find(q=>q.q===body.q);
  if (!question || !question.options.some(o=>o.key===body.a)) return jsonError2(400,"Choose one of the offered answers.");
  payload.followups.push({q:body.q,a:body.a});
  const saved=await env.DB.prepare("UPDATE reports SET payload=?1 WHERE id=?2 AND payload=?3")
    .bind(JSON.stringify(payload),reportId,report.payload).run();
  if (saved.meta.changes!==1) return jsonError2(409,"Another answer was saved. Please try again.");
  return json({ok:true});
}
__name(handlePatchFollowup, "handlePatchFollowup");
async function handleGetFollowupQuestion(request, env, url, reportId) {
  const session = await getSession(request, env);
  if (!session) return jsonError2(401, "Sign in required.");
  const user = await env.DB.prepare("SELECT banned FROM users WHERE sub = ?1").bind(session.sub).first();
  if (user && user.banned) return jsonError2(403, "This account can no longer post to the board.");
  const report = await env.DB.prepare("SELECT user_sub, payload FROM reports WHERE id = ?1").bind(reportId).first();
  if (!report) return jsonError2(404, "Report not found.");
  if (report.user_sub !== session.sub) return jsonError2(403, "Only the reporter can see this.");
  let payload;
  try {
    payload = JSON.parse(report.payload);
  } catch {
    return json({ question: null });
  }
  const alreadyAsked = Array.isArray(payload.followups) ? payload.followups.map((f) => f.q) : [];
  const result = await buildFollowupQuestion(env, payload, alreadyAsked, null);
  return json(result);
}
__name(handleGetFollowupQuestion, "handleGetFollowupQuestion");

// src/routes/vote.js
async function handlePutVote(request, env, url, itemId) {
  const session = await getSession(request, env);
  if (!session) return jsonError2(401, "Sign in to agree or disagree.");
  const user = await env.DB.prepare("SELECT banned FROM users WHERE sub = ?1").bind(session.sub).first();
  if (user && user.banned) return jsonError2(403, "This account can no longer post to the board.");
  const item = await env.DB.prepare("SELECT id, merged_into FROM items WHERE id = ?1").bind(itemId).first();
  if (!item) return jsonError2(404, "Report not found.");
  if (item.merged_into) {
    return json({ error: "That report was merged into another one.", mergedInto: item.merged_into }, 409);
  }
  let body;
  try {
    body = await readCareJson(request);
  } catch {
    return jsonError2(400, "Malformed request body.");
  }
  if (![1, -1, 0].includes(body.value)) return jsonError2(400, "value must be 1, -1, or 0.");
  const limitCheck = await checkVoteLimit(env, session.sub);
  if (!limitCheck.allowed) return jsonError2(429, limitCheck.message);
  const result = await castVote(env, itemId, session.sub, body.value);
  return json({ ok: true, ...result });
}
__name(handlePutVote, "handlePutVote");

// src/routes/comment.js
var BODY_MAX = 2e3;
async function handlePostComment(request, env, url) {
  const session = await getSession(request, env);
  if (!session) return jsonError2(401, "Sign in to comment.");
  const user = await env.DB.prepare("SELECT banned FROM users WHERE sub = ?1").bind(session.sub).first();
  if (user && user.banned) return jsonError2(403, "This account can no longer post to the board.");
  let payload;
  try {
    payload = await readCareJson(request);
  } catch {
    return jsonError2(400, "Malformed request body.");
  }
  const itemId = Number(payload.itemId);
  const bodyText = typeof payload.body === "string" ? payload.body.trim() : "";
  if (!Number.isInteger(itemId)) return jsonError2(400, "itemId is required.");
  if (!bodyText) return jsonError2(400, "Comment can't be empty.");
  if (bodyText.length > BODY_MAX) return jsonError2(400, `Comments are capped at ${BODY_MAX} characters.`);
  const item = await env.DB.prepare("SELECT id, merged_into FROM items WHERE id = ?1").bind(itemId).first();
  if (!item) return jsonError2(404, "Report not found.");
  if (item.merged_into) {
    return json({ error: "That report was merged into another one.", mergedInto: item.merged_into }, 409);
  }
  let parentId = null;
  if (payload.parentId != null) {
    parentId = Number(payload.parentId);
    const parent = await env.DB.prepare("SELECT id, item_id, parent_id FROM comments WHERE id = ?1").bind(parentId).first();
    if (!parent || parent.item_id !== itemId) return jsonError2(400, "Parent comment not found on this report.");
    if (parent.parent_id != null) return jsonError2(400, "Comments can only nest one level deep.");
  }
  const limitCheck = await checkCommentLimit(env, session.sub);
  if (!limitCheck.allowed) return jsonError2(429, limitCheck.message);
  const held = await isHeld(env, bodyText);
  const now = Math.floor(Date.now() / 1e3);
  const insert = env.DB.prepare(
    "INSERT INTO comments (item_id, user_sub, parent_id, body, created_at, held) VALUES (?1, ?2, ?3, ?4, ?5, ?6) RETURNING id"
  ).bind(itemId, session.sub, parentId, bodyText, now, held ? 1 : 0);
  const statements = [insert];
  if (!held) {
    statements.push(
      env.DB.prepare("UPDATE items SET comments_count = comments_count + 1 WHERE id = ?1").bind(itemId)
    );
  }
  const [insertResult] = await env.DB.batch(statements);
  const newId = insertResult.results?.[0]?.id ?? null;
  return json({ ok: true, id: newId, held });
}
__name(handlePostComment, "handlePostComment");

// src/routes/related.js
async function handleGetRelated(request, env, url) {
  const type = url.searchParams.get("type");
  const area = url.searchParams.get("area");
  const part = url.searchParams.get("part");
  if (!["bug", "idea"].includes(type) || !area) {
    return jsonError2(400, "type and area are required.");
  }
  let query = `SELECT id, title, status, reports_count, agree_count, disagree_count, net
               FROM items
               WHERE held = 0 AND merged_into IS NULL AND status IN ('open','planned','in_progress')
                 AND type = ?1 AND area = ?2`;
  const params = [type, area];
  if (part) {
    query += " AND part = ?3";
    params.push(part);
  }
  query += " ORDER BY reports_count DESC, net DESC, id ASC LIMIT 5";
  const { results } = await env.DB.prepare(query).bind(...params).all();
  return json({
    items: results.map((r) => ({
      id: r.id,
      title: r.title,
      status: r.status,
      reportsCount: r.reports_count,
      net: r.net
    }))
  });
}
__name(handleGetRelated, "handleGetRelated");

// src/routes/me.js
async function handleGetMe(request, env, url) {
  const session = await getSession(request, env);
  if (!session) return json({ loggedIn: false });
  return json({
    loggedIn: true,
    name: session.name,
    avatar: session.avatar,
    isOwner: session.isOwner
  }, 200, { "Cache-Control": "private, no-store", Vary: "Cookie" });
}
__name(handleGetMe, "handleGetMe");
var MAX_VOTE_IDS = 90;
async function handleGetMyVotes(request, env, url) {
  const headers = { "Cache-Control": "private, no-store" };
  const session = await getSession(request, env);
  if (!session) return json({ votes: {} }, 200, headers);
  const ids = [...new Set(
    (url.searchParams.get("ids") || "").split(",").map((s) => parseInt(s.trim(), 10)).filter((n) => Number.isInteger(n) && n > 0)
  )].slice(0, MAX_VOTE_IDS);
  if (ids.length === 0) return json({ votes: {} }, 200, headers);
  const placeholders = ids.map((_, i) => `?${i + 2}`).join(",");
  const { results } = await env.DB.prepare(
    `SELECT item_id, value, created_at FROM votes WHERE user_sub = ?1 AND item_id IN (${placeholders})`
  ).bind(session.sub, ...ids).all();
  const votes = {};
  for (const row of results) votes[row.item_id] = { value: row.value, createdAt: row.created_at };
  return json({ votes }, 200, headers);
}
__name(handleGetMyVotes, "handleGetMyVotes");

// src/lib/bands.js
function floorLog2(n) {
  return 31 - Math.clz32(n);
}
__name(floorLog2, "floorLog2");
function band(net) {
  if (net === 0) return 0;
  if (net >= 1) return floorLog2(net) + 1;
  return -(floorLog2(-net) + 1);
}
__name(band, "band");

// src/lib/feed.js
var LIVE_STATUSES = /* @__PURE__ */ new Set(["open", "planned", "in_progress"]);
var NEW_MAX_AGE_DAYS = 21;
var NEW_MAX_TOTAL = 5;
var TRENDING_MIN_VEL = 3;
var TRENDING_MIN_TOTAL = 5;
var SHIPPED_STRIP_SIZE = 5;
var SLOT_PATTERN = ["T", "R", "N", "T"];
var FALLBACK = { T: ["T", "R", "N"], R: ["R", "T", "N"], N: ["N", "T", "R"] };
function assembleFeed(items, velByItem, nowSeconds) {
  const DAY = 86400;
  const decorated = items.map((it) => {
    const net = it.net;
    const total = it.total;
    const vel = velByItem.get(it.id) || 0;
    const ageDays = (nowSeconds - it.created_at) / DAY;
    const newEligible = ageDays <= NEW_MAX_AGE_DAYS && total < NEW_MAX_TOTAL && net >= 0 && it.status === "open";
    const trendingEligible = vel >= TRENDING_MIN_VEL && net >= 0 && total >= TRENDING_MIN_TOTAL && LIVE_STATUSES.has(it.status);
    return { ...it, _band: band(net), _vel: vel, _newEligible: newEligible, _trendingEligible: trendingEligible };
  });
  const shipped = decorated.filter((it) => it.status === "shipped").sort((a, b) => (b.owner_note_at || 0) - (a.owner_note_at || 0) || a.id - b.id).slice(0, SHIPPED_STRIP_SIZE);
  const topOrder = [...decorated].sort(cmpTop);
  const trendingOrder = decorated.filter((it) => it._trendingEligible).sort(cmpTrending);
  const newOrder = decorated.filter((it) => it._newEligible).sort(cmpNew);
  const lanes = { T: topOrder, R: trendingOrder, N: newOrder };
  const cursors = { T: 0, R: 0, N: 0 };
  const placed = /* @__PURE__ */ new Set();
  const feed = [];
  const targetCount = decorated.length;
  let slotIndex = 0;
  let safety = decorated.length * 4 + 8;
  while (feed.length < targetCount && safety-- > 0) {
    const letter = SLOT_PATTERN[slotIndex % SLOT_PATTERN.length];
    slotIndex++;
    let picked = null;
    for (const laneKey of FALLBACK[letter]) {
      const lane = lanes[laneKey];
      let c = cursors[laneKey];
      while (c < lane.length && placed.has(lane[c].id)) c++;
      cursors[laneKey] = c;
      if (c < lane.length) {
        picked = lane[c];
        cursors[laneKey] = c + 1;
        break;
      }
    }
    if (!picked) break;
    placed.add(picked.id);
    feed.push(picked);
  }
  const { items: guardedFeed, violations } = guardrail(feed);
  if (violations > 0) {
    console.warn(`[feed guardrail] pass #1 fixed ${violations} net<0-before-net>=0 orderings \u2014 unexpected`);
  }
  return { shipped, feed: guardedFeed };
}
__name(assembleFeed, "assembleFeed");
function guardrail(orderedItems, { assertOnly = false } = {}) {
  const nonNeg = [];
  const neg = [];
  let violations = 0;
  let seenNeg = false;
  for (const it of orderedItems) {
    if (it.net < 0) {
      neg.push(it);
      seenNeg = true;
    } else {
      if (seenNeg) violations++;
      nonNeg.push(it);
    }
  }
  if (assertOnly && violations > 0) {
    console.warn(`[feed guardrail] pass #2 found ${violations} net<0-before-net>=0 violations \u2014 upstream ordering bug`);
  }
  neg.sort((a, b) => b._band - a._band || a.id - b.id);
  return { items: [...nonNeg, ...neg], violations };
}
__name(guardrail, "guardrail");
function applyGuardrail(orderedItems) {
  return guardrail(orderedItems).items;
}
__name(applyGuardrail, "applyGuardrail");
function tagFor(item) {
  if (item._trendingEligible) return "trending";
  if (item._newEligible) return "new";
  if (item._band >= 3) return "top";
  return null;
}
__name(tagFor, "tagFor");
function cmpTop(a, b) {
  return b._band - a._band || b.reports_count - a.reports_count || a.id - b.id;
}
__name(cmpTop, "cmpTop");
function cmpTrending(a, b) {
  return b._vel - a._vel || b.id - a.id;
}
__name(cmpTrending, "cmpTrending");
function cmpNew(a, b) {
  return b.created_at - a.created_at || b.id - a.id;
}
__name(cmpNew, "cmpNew");

// src/routes/feed.js
var PAGE_SIZE = 24;
var VEL_WINDOW_DAYS = 7;
var CACHE_TTL_SECONDS = 60;
var VALID_STATUS_FILTER = /* @__PURE__ */ new Set(["open", "planned", "in_progress", "shipped", "declined"]);
var VALID_TYPE_FILTER = /* @__PURE__ */ new Set(["bug", "idea"]);
async function handleGetFeed(request, env, ctx, url) {
  const cache2 = caches.default;
  const cacheKey = new Request(url.toString(), { method: "GET" });
  const cached = await cache2.match(cacheKey);
  if (cached) return cached;
  const response = await computeFeed(env, url);
  if (response.status === 200) {
    const toCache = response.clone();
    ctx.waitUntil(cache2.put(cacheKey, toCache));
  }
  return response;
}
__name(handleGetFeed, "handleGetFeed");
async function computeFeed(env, url) {
  const now = Math.floor(Date.now() / 1e3);
  const params = url.searchParams;
  const area = params.get("area");
  const type = params.get("type");
  const statusFilter = params.get("status");
  const q = (params.get("q") || "").trim();
  const page = Math.max(0, parseInt(params.get("page") || "0", 10) || 0);
  const sort = params.get("sort") === "newest" ? "newest" : "woven";
  const where = ["held = 0", "merged_into IS NULL"];
  const binds = [];
  if (statusFilter && VALID_STATUS_FILTER.has(statusFilter)) {
    where.push(`status = ?${binds.length + 1}`);
    binds.push(statusFilter);
  } else {
    where.push("status != 'declined'");
  }
  if (area) {
    where.push(`area = ?${binds.length + 1}`);
    binds.push(area);
  }
  if (type && VALID_TYPE_FILTER.has(type)) {
    where.push(`type = ?${binds.length + 1}`);
    binds.push(type);
  }
  if (q) {
    where.push(`title LIKE ?${binds.length + 1} ESCAPE '\\'`);
    binds.push(`%${q.replace(/[%_]/g, (m) => "\\" + m)}%`);
  }
  const rankQuery = `SELECT id, status, created_at, pinned, net, total, reports_count, owner_note_at
    FROM items WHERE ${where.join(" AND ")}`;
  const windowStart = now - VEL_WINDOW_DAYS * 86400;
  const [rankResult, velResult] = await Promise.all([
    env.DB.prepare(rankQuery).bind(...binds).all(),
    env.DB.prepare(
      `SELECT item_id, SUM(CASE WHEN value = 1 THEN 1 ELSE 0 END) - SUM(CASE WHEN value = -1 THEN 1 ELSE 0 END) AS vel
       FROM votes WHERE created_at >= ?1 GROUP BY item_id`
    ).bind(windowStart).all()
  ]);
  const rankRows = rankResult.results;
  const velByItem = /* @__PURE__ */ new Map();
  for (const row of velResult.results) velByItem.set(row.item_id, row.vel);
  const { shipped, feed } = assembleFeed(rankRows, velByItem, now);
  let mainList = feed;
  if (sort === "newest") {
    mainList = applyGuardrail([...feed].sort((a, b) => b.created_at - a.created_at || b.id - a.id));
  }
  const totalCount = mainList.length;
  const pageStart = page * PAGE_SIZE;
  const { items: pageItems } = guardrail(mainList.slice(pageStart, pageStart + PAGE_SIZE), { assertOnly: true });
  const shownIds = [.../* @__PURE__ */ new Set([...shipped.map((it) => it.id), ...pageItems.map((it) => it.id)])];
  const displayById = await fetchDisplayRows(env, shownIds);
  const card = /* @__PURE__ */ __name((rankItem) => publicCard(rankItem, displayById.get(rankItem.id)), "card");
  const body = {
    shipped: shipped.map(card),
    items: pageItems.map(card),
    page,
    pageSize: PAGE_SIZE,
    totalCount,
    hasMore: pageStart + PAGE_SIZE < totalCount,
    sort,
    // When this snapshot was computed — identical for every viewer of this
    // cache entry (NOT per-user), so it's safe inside the shared cache. Lets
    // a logged-in client tell whether a since-cast vote of theirs predates
    // or postdates the net numbers on screen (see /api/me/votes + board.js).
    generatedAt: now
  };
  return json(body, 200, {
    "Cache-Control": `public, max-age=${CACHE_TTL_SECONDS}, stale-while-revalidate=120`
  });
}
__name(computeFeed, "computeFeed");
async function fetchDisplayRows(env, ids) {
  const map = /* @__PURE__ */ new Map();
  if (ids.length === 0) return map;
  const placeholders = ids.map((_, i) => `?${i + 1}`).join(",");
  const { results } = await env.DB.prepare(
    `SELECT id, type, area, part, title, agree_count, disagree_count, comments_count, owner_note
     FROM items WHERE id IN (${placeholders})`
  ).bind(...ids).all();
  for (const row of results) map.set(row.id, row);
  return map;
}
__name(fetchDisplayRows, "fetchDisplayRows");
function publicCard(rankItem, display) {
  const d = display || {};
  return {
    id: rankItem.id,
    type: d.type ?? null,
    area: d.area ?? null,
    part: d.part ?? null,
    title: d.title ?? "",
    status: rankItem.status,
    net: rankItem.net,
    agreeCount: d.agree_count ?? null,
    disagreeCount: d.disagree_count ?? null,
    reportsCount: rankItem.reports_count,
    commentsCount: d.comments_count ?? null,
    createdAt: rankItem.created_at,
    ownerNote: d.owner_note || null,
    tag: tagFor(rankItem)
  };
}
__name(publicCard, "publicCard");

// src/routes/item.js
var CACHE_TTL_SECONDS2 = 30;
async function handleGetItem(request, env, url, itemId) {
  const item = await env.DB.prepare(
    `SELECT id, type, area, part, title, status, created_at, agree_count, disagree_count,
       reports_count, comments_count, net, total, owner_note, owner_note_at, merged_into, held, pinned
     FROM items WHERE id = ?1`
  ).bind(itemId).first();
  if (!item || item.held) return jsonError2(404, "Report not found.");
  if (item.merged_into) {
    return json({ mergedInto: item.merged_into }, 409);
  }
  const { results: reportRows } = await env.DB.prepare(
    `SELECT r.id, r.payload, r.created_at, u.name AS reporter_name, u.avatar_url
     FROM reports r JOIN users u ON u.sub = r.user_sub
     WHERE r.item_id = ?1 AND r.held = 0
     ORDER BY r.created_at ASC, r.id ASC`
  ).bind(itemId).all();
  const reports = reportRows.map((r) => {
    let payload = {};
    try {
      payload = JSON.parse(r.payload);
    } catch {
    }
    const ctx = payload.ctx || {};
    return {
      reporterName: r.reporter_name || "A GM",
      avatar: r.avatar_url || null,
      createdAt: r.created_at,
      // coarse context only
      version: careContext(ctx.v),
      os: ctx.os || null,
      browser: ctx.browser || null,
      symptom: payload.symptom || null,
      frequency: payload.frequency || null,
      expected: payload.expected || null,
      actual: payload.actual || null,
      freetext: payload.freetext || "",
      importance: payload.importance || null,
      ask: payload.ask || null,
      why: payload.why || null,
      doneLooksLike: payload.doneLooksLike || null,
      followups: (payload.followups || []).map(f=>({question:careFollowupLabel(payload,f),answer:careAnswerLabel(payload,f)}))
    };
  });
  const { results: commentRows } = await env.DB.prepare(
    `SELECT c.id, c.parent_id, c.body, c.created_at, u.name AS author_name, u.avatar_url
     FROM comments c JOIN users u ON u.sub = c.user_sub
     WHERE c.item_id = ?1 AND c.held = 0 AND c.deleted = 0
     ORDER BY c.created_at ASC, c.id ASC`
  ).bind(itemId).all();
  const commentsById = /* @__PURE__ */ new Map();
  const topLevel = [];
  for (const c of commentRows) {
    const node = {
      id: c.id,
      parentId: c.parent_id,
      body: c.body,
      createdAt: c.created_at,
      authorName: c.author_name || "A GM",
      avatar: c.avatar_url || null,
      replies: []
    };
    commentsById.set(c.id, node);
  }
  for (const node of commentsById.values()) {
    if (node.parentId && commentsById.has(node.parentId)) {
      commentsById.get(node.parentId).replies.push(node);
    } else {
      topLevel.push(node);
    }
  }
  let myVote = 0;
  const session = await getSession(request, env);
  if (session) {
    const v = await env.DB.prepare("SELECT value FROM votes WHERE item_id = ?1 AND user_sub = ?2").bind(itemId, session.sub).first();
    if (v) myVote = v.value;
  }
  const body = {
    id: item.id,
    type: item.type,
    area: item.area,
    part: item.part,
    title: item.title,
    status: item.status,
    net: item.net,
    agreeCount: item.agree_count,
    disagreeCount: item.disagree_count,
    reportsCount: item.reports_count,
    commentsCount: item.comments_count,
    createdAt: item.created_at,
    ownerNote: item.owner_note || null,
    ownerNoteAt: item.owner_note_at || null,
    reports,
    comments: topLevel,
    myVote
  };
  const headers = session ? { "Cache-Control": "private, no-store", Vary: "Cookie" } : { "Cache-Control": `public, max-age=${CACHE_TTL_SECONDS2}`, Vary: "Cookie" };
  return json(body, 200, headers);
}
__name(handleGetItem, "handleGetItem");

// src/lib/trigram.js
function trigrams(str) {
  const s = "  " + (str || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim() + "  ";
  const set = /* @__PURE__ */ new Set();
  for (let i = 0; i < s.length - 2; i++) set.add(s.slice(i, i + 3));
  return set;
}
__name(trigrams, "trigrams");
function trigramSimilarity(a, b) {
  const ta = trigrams(a);
  const tb = trigrams(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const g of ta) if (tb.has(g)) inter++;
  const union = ta.size + tb.size - inter;
  return union === 0 ? 0 : inter / union;
}
__name(trigramSimilarity, "trigramSimilarity");

// src/lib/desk.js
var LIVE = "('open','planned','in_progress')";
async function deterministicDigest(env, velByItem) {
  const { results: areaRows } = await env.DB.prepare(
    `SELECT area,
            COUNT(*) AS threads,
            SUM(reports_count) AS reports,
            SUM(net) AS net_sum
     FROM items
     WHERE held = 0 AND merged_into IS NULL AND status != 'declined'
     GROUP BY area
     ORDER BY net_sum DESC`
  ).all();
  const { results: topThreads } = await env.DB.prepare(
    `SELECT id, area, part, title, status, net, reports_count, created_at
     FROM items
     WHERE held = 0 AND merged_into IS NULL AND status != 'declined'
     ORDER BY area ASC, net DESC, reports_count DESC, id ASC`
  ).all();
  const byArea = /* @__PURE__ */ new Map();
  for (const t of topThreads) {
    if (!byArea.has(t.area)) byArea.set(t.area, []);
    const list = byArea.get(t.area);
    if (list.length < 2) {
      list.push({
        id: t.id,
        title: t.title,
        status: t.status,
        net: t.net,
        reportsCount: t.reports_count,
        vel: velByItem.get(t.id) || 0,
        band: band(t.net)
      });
    }
  }
  const surfacedIds = [];
  for (const list of byArea.values()) for (const t of list) surfacedIds.push(t.id);
  const versionSpread = await versionSpreadFor(env, surfacedIds);
  return areaRows.map((a) => ({
    area: a.area,
    threads: a.threads,
    reports: a.reports,
    net: a.net_sum,
    topThreads: (byArea.get(a.area) || []).map((t) => ({ ...t, versions: versionSpread.get(t.id) || {} }))
  }));
}
__name(deterministicDigest, "deterministicDigest");
async function versionSpreadFor(env, itemIds) {
  const map = /* @__PURE__ */ new Map();
  if (itemIds.length === 0) return map;
  const ph = itemIds.map((_, i) => `?${i + 1}`).join(",");
  const { results } = await env.DB.prepare(
    `SELECT item_id, payload FROM reports WHERE item_id IN (${ph}) AND held = 0`
  ).bind(...itemIds).all();
  for (const r of results) {
    let v = null;
    try {
      v = (JSON.parse(r.payload).ctx || {}).v || null;
    } catch {
    }
    const key = v || "unknown";
    if (!map.has(r.item_id)) map.set(r.item_id, {});
    const t = map.get(r.item_id);
    t[key] = (t[key] || 0) + 1;
  }
  return map;
}
__name(versionSpreadFor, "versionSpreadFor");
async function deskSummary(env, sinceEpoch) {
  const since = sinceEpoch || 0;
  const [newReports, joins, comments, holds, heldComments, movers] = await Promise.all([
    env.DB.prepare("SELECT COUNT(*) AS n FROM reports WHERE created_at >= ?1").bind(since).first(),
    // joins = reports on items that already existed before the report (rough: reports beyond the first per item in window)
    env.DB.prepare("SELECT COUNT(*) AS n FROM reports r WHERE r.created_at >= ?1 AND r.item_id IN (SELECT item_id FROM reports GROUP BY item_id HAVING COUNT(*) > 1)").bind(since).first(),
    env.DB.prepare("SELECT COUNT(*) AS n FROM comments WHERE created_at >= ?1 AND deleted = 0").bind(since).first(),
    env.DB.prepare("SELECT COUNT(*) AS n FROM items WHERE held = 1").first(),
    env.DB.prepare("SELECT COUNT(*) AS n FROM comments WHERE held = 1 AND deleted = 0").first(),
    env.DB.prepare(`SELECT COUNT(*) AS n FROM items WHERE held = 0 AND merged_into IS NULL AND status IN ${LIVE} AND net >= 4`).first()
  ]);
  return {
    newReports: newReports.n,
    joins: joins.n,
    comments: comments.n,
    holds: holds.n + heldComments.n,
    movers: movers.n
  };
}
__name(deskSummary, "deskSummary");
async function decisionQueue(env, velByItem) {
  const queue = [];
  const { results: liveItems } = await env.DB.prepare(
    `SELECT id, area, part, title, net, reports_count
     FROM items WHERE held = 0 AND merged_into IS NULL AND status != 'declined'
     ORDER BY area, part, id`
  ).all();
  const buckets = /* @__PURE__ */ new Map();
  for (const it of liveItems) {
    const key = it.area + "|" + (it.part || "");
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(it);
  }
  const mergeSuspects = [];
  for (const list of buckets.values()) {
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const sim = trigramSimilarity(list[i].title, list[j].title);
        if (sim >= 0.5) {
          const a = list[i], b = list[j];
          const winner = pickWinner(a, b);
          const loser = winner === a ? b : a;
          mergeSuspects.push({
            kind: "merge",
            winnerId: winner.id,
            winnerTitle: winner.title,
            loserId: loser.id,
            loserTitle: loser.title,
            similarity: Math.round(sim * 100)
          });
        }
      }
    }
  }
  for (const m of mergeSuspects.slice(0, 5)) queue.push(m);
  const { results: moverRows } = await env.DB.prepare(
    `SELECT id, title, net, reports_count FROM items
     WHERE held = 0 AND merged_into IS NULL AND status = 'open' AND net >= 0
     ORDER BY id`
  ).all();
  const movers = moverRows.map((m) => ({ ...m, vel: velByItem.get(m.id) || 0 })).filter((m) => m.vel >= 3).sort((a, b) => b.vel - a.vel).slice(0, 5).map((m) => ({ kind: "mover", id: m.id, title: m.title, net: m.net, vel: m.vel, reportsCount: m.reports_count }));
  for (const m of movers) queue.push(m);
  const { results: heldItems } = await env.DB.prepare(
    `SELECT id, title, created_by FROM items WHERE held = 1 ORDER BY id DESC LIMIT 5`
  ).all();
  for (const h of heldItems) queue.push({ kind: "hold", target: "item", id: h.id, title: h.title });
  const { results: heldComments } = await env.DB.prepare(
    `SELECT c.id, c.item_id, c.body FROM comments c WHERE c.held = 1 AND c.deleted = 0 ORDER BY c.id DESC LIMIT 5`
  ).all();
  for (const h of heldComments) queue.push({ kind: "hold", target: "comment", id: h.id, itemId: h.item_id, body: h.body.slice(0, 120) });
  const { results: controversial } = await env.DB.prepare(
    `SELECT id, title, net, reports_count FROM items
     WHERE held = 0 AND merged_into IS NULL AND net < 0 AND reports_count >= 3
     ORDER BY reports_count DESC LIMIT 3`
  ).all();
  for (const c of controversial) queue.push({ kind: "controversial", id: c.id, title: c.title, net: c.net, reportsCount: c.reports_count });
  const dayAgo = Math.floor(Date.now() / 1e3) - 86400;
  const { results: prolific } = await env.DB.prepare(
    `SELECT created_by AS sub, COUNT(*) AS n FROM items WHERE created_at >= ?1 GROUP BY created_by HAVING n >= 4 ORDER BY n DESC LIMIT 3`
  ).bind(dayAgo).all();
  for (const p of prolific) queue.push({ kind: "prolific", sub: p.sub, count: p.n });
  return queue;
}
__name(decisionQueue, "decisionQueue");
function pickWinner(a, b) {
  if (b.reports_count !== a.reports_count) return b.reports_count > a.reports_count ? b : a;
  if (b.net !== a.net) return b.net > a.net ? b : a;
  return a.id < b.id ? a : b;
}
__name(pickWinner, "pickWinner");
async function buildBriefData(env, itemId) {
  const item = await env.DB.prepare(
    `SELECT id, type, area, part, title, status, net, reports_count FROM items WHERE id = ?1`
  ).bind(itemId).first();
  if (!item) return null;
  const { results: reports } = await env.DB.prepare(
    `SELECT payload, created_at FROM reports WHERE item_id = ?1 AND held = 0 ORDER BY created_at ASC`
  ).bind(itemId).all();
  const parsed = reports.map((r) => {
    try {
      return JSON.parse(r.payload);
    } catch {
      return {};
    }
  });
  const symptomTally = {};
  const freqTally = {};
  const detailTally = {};
  const importanceTally = {};
  const versions = {};
  const osTally = {};
  const browserTally = {};
  const builds = {};
  const expectedActual = [];
  const quotes = [];
  const followupTally = {};
  for (const p of parsed) {
    if (p.symptom) symptomTally[p.symptom] = (symptomTally[p.symptom] || 0) + 1;
    if (p.frequency) freqTally[p.frequency] = (freqTally[p.frequency] || 0) + 1;
    if (p.symptom_detail) detailTally[p.symptom_detail] = (detailTally[p.symptom_detail] || 0) + 1;
    if (p.importance) importanceTally[p.importance] = (importanceTally[p.importance] || 0) + 1;
    const ctx = p.ctx || {};
    if (ctx.v) versions[ctx.v] = (versions[ctx.v] || 0) + 1;
    if (ctx.os) osTally[ctx.os] = (osTally[ctx.os] || 0) + 1;
    if (ctx.browser) browserTally[ctx.browser] = (browserTally[ctx.browser] || 0) + 1;
    if (ctx.build) builds[ctx.build] = (builds[ctx.build] || 0) + 1;
    if (p.expected || p.actual) expectedActual.push({ expected: p.expected || "", actual: p.actual || "" });
    if (p.freetext) quotes.push(p.freetext);
    if (p.ask) quotes.push(p.ask);
    for (const f of p.followups || []) {
      const k = f.q + "=" + f.a;
      followupTally[k] = (followupTally[k] || 0) + 1;
    }
  }
  return {
    id: item.id,
    type: item.type,
    area: item.area,
    part: item.part,
    title: item.title,
    status: item.status,
    net: item.net,
    reportsCount: item.reports_count,
    reportCount: parsed.length,
    symptomTally,
    freqTally,
    detailTally,
    importanceTally,
    versions,
    osTally,
    browserTally,
    builds,
    expectedActual: expectedActual.slice(0, 8),
    quotes: quotes.slice(0, 6),
    followupTally
  };
}
__name(buildBriefData, "buildBriefData");
function renderBriefText(d, mergedIds) {
  const L = [];
  const tally = /* @__PURE__ */ __name((obj, prefix = "") => {
    const entries = Object.entries(obj).sort((a, b) => b[1] - a[1]);
    return entries.map(([k, n]) => `${prefix}${k} \xD7${n}`).join(", ") || "\u2014";
  }, "tally");
  L.push(`BUILD BRIEF \u2014 #${d.id} ${areaTitle(d.area)}: ${d.title}`);
  const impStr = tally(d.importanceTally);
  L.push(`Demand: ${d.reportsCount} GMs \xB7 ${d.net >= 0 ? "+" : ""}${d.net} net${Object.keys(d.importanceTally).length ? " \xB7 importance: " + impStr : ""}`);
  if (d.type === "bug") {
    L.push(`Symptom matrix: ${tally(d.symptomTally)}; ${tally(d.freqTally)}${Object.keys(d.detailTally).length ? "; detail: " + tally(d.detailTally) : ""}.`);
  }
  const envBits = [];
  if (Object.keys(d.versions).length) envBits.push(tally(d.versions, "v"));
  const osBrowser = tally(d.osTally);
  if (Object.keys(d.osTally).length) envBits.push(osBrowser);
  if (Object.keys(d.browserTally).length) envBits.push(tally(d.browserTally));
  if (Object.keys(d.builds).length) envBits.push(tally(d.builds) + " build");
  L.push(`Environment: ${envBits.join(" \xB7 ") || "\u2014"}.`);
  if (d.expectedActual.length) {
    L.push("Expected vs actual (verbatim): " + d.expectedActual.map((e) => `"${e.expected}" \u2192 "${e.actual}"`).join("; ") + ".");
  }
  if (Object.keys(d.followupTally).length) {
    L.push("Follow-up answers: " + Object.entries(d.followupTally).map(([k, n]) => `${n}\xD7 ${k}`).join(", ") + ".");
  }
  if (d.quotes.length) {
    L.push("GM quotes worth keeping: " + d.quotes.map((q) => `"${q}"`).join(" | "));
  }
  L.push("Acceptance (drafted from reports): " + draftAcceptance(d));
  const links = [`/item/?id=${d.id}`].concat((mergedIds || []).map((m) => `merged #${m}`));
  L.push("Board links: " + links.join(" + "));
  return L.join("\n");
}
__name(renderBriefText, "renderBriefText");
function draftAcceptance(d) {
  if (d.type === "idea") {
    return `the tool does what was asked, verified by a GM who requested it.`;
  }
  const parts = [];
  const topDetail = Object.entries(d.detailTally).sort((a, b) => b[1] - a[1])[0];
  if (d.symptomTally.work_disappeared) parts.push("the affected work survives the reported action");
  if (topDetail) parts.push(`survives "${topDetail[0]}"`);
  const platforms = Object.keys(d.osTally);
  if (platforms.length) parts.push(`verified on ${platforms.join(", ")}`);
  if (parts.length === 0) parts.push("the reported symptom no longer occurs on the reported platforms");
  return parts.join("; ") + ".";
}
__name(draftAcceptance, "draftAcceptance");
function areaTitle(area) {
  return String(area || "").replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
__name(areaTitle, "areaTitle");

// src/routes/desk.js
var VEL_WINDOW_DAYS2 = 7;
async function requireOwner(request, env) {
  const session = await getSession(request, env);
  if (!session || !session.isOwner) {
    return { ok: false, response: await notFound(env) };
  }
  return { ok: true, session };
}
__name(requireOwner, "requireOwner");
async function velocityMap(env) {
  const windowStart = Math.floor(Date.now() / 1e3) - VEL_WINDOW_DAYS2 * 86400;
  const { results } = await env.DB.prepare(
    `SELECT item_id, SUM(CASE WHEN value = 1 THEN 1 ELSE 0 END) - SUM(CASE WHEN value = -1 THEN 1 ELSE 0 END) AS vel
     FROM votes WHERE created_at >= ?1 GROUP BY item_id`
  ).bind(windowStart).all();
  const map = /* @__PURE__ */ new Map();
  for (const r of results) map.set(r.item_id, r.vel);
  return map;
}
__name(velocityMap, "velocityMap");
async function logAction(env, action, itemId, detail) {
  await env.DB.prepare("INSERT INTO owner_log (at, action, item_id, detail) VALUES (?1, ?2, ?3, ?4)").bind(Math.floor(Date.now() / 1e3), action, itemId || null, detail || null).run();
}
__name(logAction, "logAction");
function deskJson(data, status = 200) {
  return json(data, status, { "Cache-Control": "private, no-store" });
}
__name(deskJson, "deskJson");
async function routeDeskApi(request, env, url) {
  const gate = await requireOwner(request, env);
  if (!gate.ok) return gate.response;
  const { pathname } = url;
  const method = request.method;
  if (method === "GET" && pathname === "/api/desk/summary") {
    const lastVisit = Number(url.searchParams.get("since")) || Math.floor(Date.now() / 1e3) - 7 * 86400;
    const summary = await deskSummary(env, lastVisit);
    const usage = await todayUsage(env);
    const lastDigest = await env.DB.prepare("SELECT created_at FROM digests ORDER BY created_at DESC LIMIT 1").first();
    return deskJson({ summary, usage, lastDigestAt: lastDigest?.created_at || null });
  }
  if (pathname === "/api/desk/digest") {
    const vel = await velocityMap(env);
    if (method === "POST") {
      return deskJson(await computeDigest(env, vel, true));
    }
    return deskJson(await computeDigest(env, vel, false));
  }
  if (method === "GET" && pathname === "/api/desk/queue") {
    const vel = await velocityMap(env);
    const queue = await decisionQueue(env, vel);
    return deskJson({ queue });
  }
  if (method === "GET" && pathname.match(/^\/api\/desk\/item\/\d+$/)) {
    const id = Number(pathname.split("/").pop());
    return deskJson(await deskItemDetail(env, id));
  }
  const actionMatch = pathname.match(/^\/api\/desk\/item\/(\d+)\/(status|note|pin|hide|merge|remove)$/);
  if (method === "POST" && actionMatch) {
    return deskAction(request, env, Number(actionMatch[1]), actionMatch[2]);
  }
  const banMatch = pathname.match(/^\/api\/desk\/user\/([^/]+)\/ban$/);
  if (method === "POST" && banMatch) {
    return deskBan(env, decodeURIComponent(banMatch[1]));
  }
  if (method === "POST" && pathname === "/api/desk/brief") {
    return deskBrief(request, env);
  }
  return jsonError2(404, "Not found.");
}
__name(routeDeskApi, "routeDeskApi");
async function computeDigest(env, vel, forceRefresh) {
  const areas = await deterministicDigest(env, vel);
  const hashSource = JSON.stringify(areas.map((a) => [a.area, a.threads, a.reports, a.net, a.topThreads.map((t) => [t.id, t.net, t.reportsCount])]));
  const contentHash = await sha256(hashSource);
  if (!forceRefresh) {
    const cached = await env.DB.prepare("SELECT body FROM digests WHERE scope = ?1 AND content_hash = ?2 ORDER BY created_at DESC LIMIT 1").bind("digest", contentHash).first();
    if (cached) {
      try {
        return { areas, synthesis: JSON.parse(cached.body), cached: true };
      } catch {
      }
    }
  }
  const synthesis = {};
  const hotThreads = [];
  for (const a of areas) for (const t of a.topThreads) if (t.reportsCount >= 3 || t.vel >= 3) hotThreads.push({ area: a.area, ...t });
  for (const t of hotThreads.slice(0, 12)) {
    const sentence = await synthesizeThread(env, t);
    if (sentence) synthesis[t.id] = sentence;
  }
  if (Object.keys(synthesis).length > 0) {
    await env.DB.prepare("INSERT INTO digests (scope, content_hash, body, created_at) VALUES (?1, ?2, ?3, ?4)").bind("digest", contentHash, JSON.stringify(synthesis), Math.floor(Date.now() / 1e3)).run();
    await bumpUsage(env, "ai", hotThreads.length);
  }
  return { areas, synthesis, cached: false };
}
__name(computeDigest, "computeDigest");
async function synthesizeThread(env, thread) {
  const { results } = await env.DB.prepare(
    "SELECT payload FROM reports WHERE item_id = ?1 AND held = 0 LIMIT 30"
  ).bind(thread.id).all();
  const facts = results.map((r) => {
    try {
      const p = JSON.parse(r.payload);
      return {type:p.type,symptom:p.symptom,frequency:p.frequency,detail:p.symptom_detail,expected:p.expected,actual:p.actual,
        freetext:p.freetext,ideaKind:p.ideaKind,ask:p.ask,why:p.why,doneLooksLike:p.doneLooksLike,importance:p.importance,followups:p.followups};
    } catch {
      return {};
    }
  });
  const prompt = `You are summarizing ${facts.length} bug/feature reports for one thread. Write ONE sentence, max 30 words, quantified ("N of ${facts.length} say\u2026"), grounded ONLY in this data, no invention:
` + JSON.stringify(facts);
  return runText(env, prompt, {
    system: "You output exactly one grounded, quantified sentence. Never invent facts not present in the data.",
    maxTokens: 80
  });
}
__name(synthesizeThread, "synthesizeThread");
async function deskItemDetail(env, id) {
  const item = await env.DB.prepare("SELECT * FROM items WHERE id = ?1").bind(id).first();
  if (!item) return { error: "not found" };
  const { results: reports } = await env.DB.prepare(
    `SELECT r.id, r.payload, r.created_at, r.held, u.name, u.email
     FROM reports r JOIN users u ON u.sub = r.user_sub WHERE r.item_id = ?1 ORDER BY r.created_at ASC`
  ).bind(id).all();
  return {
    item,
    reports: reports.map((r) => ({
      id: r.id,
      name: r.name,
      email: r.email,
      held: r.held,
      createdAt: r.created_at,
      payload: safeParse(r.payload)
    }))
  };
}
__name(deskItemDetail, "deskItemDetail");
async function deskAction(request, env, itemId, action) {
  let body = {};
  try {
    body = await readCareJson(request);
  } catch {
  }
  const item = await env.DB.prepare("SELECT id, status, merged_into FROM items WHERE id = ?1").bind(itemId).first();
  if (!item) return jsonError2(404, "Item not found.");
  if (action === "status") {
    const status = body.status;
    if (!["open", "planned", "in_progress", "shipped", "declined"].includes(status)) return jsonError2(400, "Bad status.");
    const now = Math.floor(Date.now() / 1e3);
    const noteAt = body.note ? now : null;
    await env.DB.prepare("UPDATE items SET status = ?1, owner_note = COALESCE(?2, owner_note), owner_note_at = COALESCE(?3, owner_note_at) WHERE id = ?4").bind(status, body.note ?? null, noteAt, itemId).run();
    await logAction(env, "status:" + status, itemId, body.note || null);
    return deskJson({ ok: true });
  }
  if (action === "note") {
    const now = Math.floor(Date.now() / 1e3);
    await env.DB.prepare("UPDATE items SET owner_note = ?1, owner_note_at = ?2 WHERE id = ?3").bind(body.note || null, body.note ? now : null, itemId).run();
    await logAction(env, "note", itemId, body.note || null);
    return deskJson({ ok: true });
  }
  if (action === "pin") {
    await env.DB.prepare("UPDATE items SET pinned = ?1 WHERE id = ?2").bind(body.pinned ? 1 : 0, itemId).run();
    await logAction(env, body.pinned ? "pin" : "unpin", itemId, null);
    return deskJson({ ok: true });
  }
  if (action === "hide") {
    await env.DB.prepare("UPDATE items SET held = ?1 WHERE id = ?2").bind(body.hidden ? 1 : 0, itemId).run();
    await logAction(env, body.hidden ? "hide" : "unhide", itemId, null);
    return deskJson({ ok: true });
  }
  if (action === "remove") {
    await env.DB.prepare("UPDATE items SET held = 1 WHERE id = ?1").bind(itemId).run();
    await logAction(env, "remove", itemId, null);
    return deskJson({ ok: true });
  }
  if (action === "merge") {
    return deskMerge(env, itemId, Number(body.intoId));
  }
  return jsonError2(400, "Unknown action.");
}
__name(deskAction, "deskAction");
async function deskMerge(env, loserId, winnerId) {
  if (!Number.isInteger(winnerId) || winnerId === loserId) return jsonError2(400, "Bad merge target.");
  const winner = await env.DB.prepare("SELECT id FROM items WHERE id = ?1").bind(winnerId).first();
  const loser = await env.DB.prepare("SELECT id, merged_into FROM items WHERE id = ?1").bind(loserId).first();
  if (!winner || !loser) return jsonError2(404, "Item not found.");
  if (loser.merged_into) return jsonError2(409, "Already merged.");
  await env.DB.prepare(
    `INSERT OR IGNORE INTO votes (item_id, user_sub, value, created_at)
     SELECT ?1, user_sub, value, created_at FROM votes WHERE item_id = ?2`
  ).bind(winnerId, loserId).run();
  await env.DB.prepare("DELETE FROM votes WHERE item_id = ?1").bind(loserId).run();
  await env.DB.prepare("UPDATE reports SET item_id = ?1 WHERE item_id = ?2").bind(winnerId, loserId).run();
  await env.DB.prepare("UPDATE comments SET item_id = ?1 WHERE item_id = ?2").bind(winnerId, loserId).run();
  await recomputeCounts(env, winnerId);
  await env.DB.prepare("UPDATE items SET merged_into = ?1, held = 0 WHERE id = ?2").bind(winnerId, loserId).run();
  await logAction(env, "merge", loserId, "into " + winnerId);
  return deskJson({ ok: true, winnerId });
}
__name(deskMerge, "deskMerge");
async function recomputeCounts(env, itemId) {
  const agree = await env.DB.prepare("SELECT COUNT(*) AS n FROM votes WHERE item_id = ?1 AND value = 1").bind(itemId).first();
  const disagree = await env.DB.prepare("SELECT COUNT(*) AS n FROM votes WHERE item_id = ?1 AND value = -1").bind(itemId).first();
  const reports = await env.DB.prepare("SELECT COUNT(*) AS n FROM reports WHERE item_id = ?1 AND held = 0").bind(itemId).first();
  const comments = await env.DB.prepare("SELECT COUNT(*) AS n FROM comments WHERE item_id = ?1 AND deleted = 0 AND held = 0").bind(itemId).first();
  await env.DB.prepare("UPDATE items SET agree_count = ?1, disagree_count = ?2, reports_count = ?3, comments_count = ?4 WHERE id = ?5").bind(agree.n, disagree.n, reports.n, comments.n, itemId).run();
}
__name(recomputeCounts, "recomputeCounts");
async function deskBan(env, sub) {
  await env.DB.prepare("UPDATE users SET banned = 1 WHERE sub = ?1").bind(sub).run();
  await logAction(env, "ban", null, sub);
  return deskJson({ ok: true });
}
__name(deskBan, "deskBan");
async function deskBrief(request, env) {
  let body = {};
  try {
    body = await readCareJson(request);
  } catch {
  }
  const ids = Array.isArray(body.items) ? body.items.map(Number).filter(Number.isInteger) : [];
  if (ids.length === 0) return jsonError2(400, "Provide items:[...].");
  const briefs = [];
  for (const id of ids.slice(0, 5)) {
    const data = await buildBriefData(env, id);
    if (!data) continue;
    const { results: merged } = await env.DB.prepare("SELECT id FROM items WHERE merged_into = ?1").bind(id).all();
    briefs.push(renderBriefText(data, merged.map((m) => m.id)));
  }
  const text = briefs.join("\n\n\u2014\u2014\u2014\n\n");
  return deskJson({ text });
}
__name(deskBrief, "deskBrief");
function utcDay() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
__name(utcDay, "utcDay");
async function todayUsage(env) {
  const row = await env.DB.prepare("SELECT worker_requests, d1_writes, ai_neurons_calls FROM usage_counters WHERE day = ?1").bind(utcDay()).first();
  return {
    day: utcDay(),
    workerRequests: row?.worker_requests || 0,
    d1Writes: row?.d1_writes || 0,
    aiCalls: row?.ai_neurons_calls || 0,
    limits: { workerRequests: 1e5, d1Writes: 1e5, aiNeurons: 1e4 }
  };
}
__name(todayUsage, "todayUsage");
async function bumpUsage(env, kind, n) {
  const col = kind === "ai" ? "ai_neurons_calls" : kind === "write" ? "d1_writes" : "worker_requests";
  await env.DB.prepare(
    `INSERT INTO usage_counters (day, ${col}) VALUES (?1, ?2)
     ON CONFLICT(day) DO UPDATE SET ${col} = ${col} + ?2`
  ).bind(utcDay(), n).run();
}
__name(bumpUsage, "bumpUsage");
async function serveDeskShell(request, env, url) {
  const gate = await requireOwner(request, env);
  if (!gate.ok) return gate.response;
  let assetPath = url.pathname === "/desk" || url.pathname === "/desk/" ? "/desk/index.html" : url.pathname;
  const res = await env.ASSETS.fetch(new Request("https://internal" + assetPath));
  const headers = new Headers(res.headers);
  headers.set("Cache-Control", "private, no-store");
  if ((headers.get("Content-Type") || "").includes("text/html")) {
    const row=await env.DB.prepare("SELECT COUNT(*) AS n FROM care_mail_outbox WHERE state IN ('pending','sending','failed')").first();
    const text=env.CARE_MAIL_ENABLED==="true" ? "Email copies are enabled." : "Email copies are waiting for one-time sender setup.";
    const banner='<aside role="status" style="padding:12px 20px;background:#fff7df;color:#493915;font:14px system-ui">'+text+' '+Number(row?.n||0)+' saved copies waiting to send.</aside>';
    const html=(await res.text()).replace(/<body([^>]*)>/i,'<body$1>'+banner);
    return new Response(html,{status:res.status,headers});
  }
  return new Response(res.body, { status: res.status, headers });
}
__name(serveDeskShell, "serveDeskShell");
function safeParse(s) {
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}
__name(safeParse, "safeParse");
async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
__name(sha256, "sha256");

// src/index.js
var WRITE_METHODS = /* @__PURE__ */ new Set(["POST", "PUT", "PATCH", "DELETE"]);
var index_default = {
  async scheduled(event,env,ctx) { ctx.waitUntil(drainCareMail(env)); },
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    try {
      if (Object.prototype.hasOwnProperty.call(CARE_CLIENT_ASSETS,url.pathname) && ["GET","HEAD"].includes(request.method)) {
        return new Response(request.method==="HEAD"?null:CARE_CLIENT_ASSETS[url.pathname],{headers:{"Content-Type":"application/javascript; charset=utf-8","Cache-Control":"public, max-age=0, must-revalidate","X-Content-Type-Options":"nosniff"}});
      }
      if (url.pathname.startsWith("/auth/")) {
        if (WRITE_METHODS.has(request.method) && !isSameOrigin(request,url)) return jsonError2(403,"Cross-site request blocked.");
        return await routeAuth(request, env, url);
      }
      if (url.pathname.startsWith("/api/")) {
        if (WRITE_METHODS.has(request.method) && !isSameOrigin(request, url)) {
          return jsonError2(403, "Cross-site request blocked.");
        }
        const response=await routeApi(request,env,ctx,url);
        if (response.ok && WRITE_METHODS.has(request.method) && ["/api/report","/api/comment"].some(p=>url.pathname===p || url.pathname.startsWith(p+"/"))) {
          ctx.waitUntil(drainCareMail(env));
        }
        return response;
      }
      if (url.pathname === "/desk" || url.pathname.startsWith("/desk/")) {
        return await serveDeskShell(request, env, url);
      }
      if (url.pathname === "/privacy" || url.pathname === "/privacy/") {
        return await servePrivacy(env);
      }
      return env.ASSETS.fetch(request);
    } catch (err) {
      return jsonError2(500, "Something broke on our end \u2014 try again in a moment.");
    }
  }
};
async function servePrivacy(env) {
  const res = await env.ASSETS.fetch(new Request("https://internal/privacy/index.html"));
  let html = await res.text();
  const email = (env.CONTACT_EMAIL || "").trim();
  const inject = `<script>window.__CONTACT_EMAIL__=${JSON.stringify(email).replace(/</g,"\\u003c")};<\/script>`;
  html = html.replace("</head>", inject + "</head>");
  return new Response(html, {
    status: res.status,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "public, max-age=300" }
  });
}
__name(servePrivacy, "servePrivacy");
async function routeApi(request, env, ctx, url) {
  const { pathname } = url;
  const method = request.method;
  if (pathname === "/api/desk/notifications") {
    const gate=await requireOwner(request,env); if (!gate.ok) return gate.response;
    if (method==="POST") {
      await env.DB.prepare("UPDATE care_mail_outbox SET state='pending',next_attempt_at=0 WHERE state='failed'").run();
      ctx.waitUntil(drainCareMail(env));
    }
    const rows=await env.DB.prepare("SELECT state,COUNT(*) AS count FROM care_mail_outbox GROUP BY state").all();
    return deskJson({enabled:env.CARE_MAIL_ENABLED==="true",counts:rows.results});
  }
  if (method === "GET" && pathname === "/api/health") {
    return json({ ok: true, service: "realmwright-care", release: "2026-09-29-care-repair", time: (/* @__PURE__ */ new Date()).toISOString() });
  }
  if (method === "GET" && pathname === "/api/me") {
    return handleGetMe(request, env, url);
  }
  if (method === "GET" && pathname === "/api/me/votes") {
    return handleGetMyVotes(request, env, url);
  }
  if (method === "POST" && pathname === "/api/report") {
    return handlePostReport(request, env, url);
  }
  const followupQMatch = pathname.match(/^\/api\/report\/(\d+)\/followup-question$/);
  if (method === "GET" && followupQMatch) {
    return handleGetFollowupQuestion(request, env, url, Number(followupQMatch[1]));
  }
  const followupMatch = pathname.match(/^\/api\/report\/(\d+)\/followup$/);
  if (method === "PATCH" && followupMatch) {
    return handlePatchFollowup(request, env, url, Number(followupMatch[1]));
  }
  const voteMatch = pathname.match(/^\/api\/vote\/(\d+)$/);
  if (method === "PUT" && voteMatch) {
    return handlePutVote(request, env, url, Number(voteMatch[1]));
  }
  if (method === "POST" && pathname === "/api/comment") {
    return handlePostComment(request, env, url);
  }
  if (method === "GET" && pathname === "/api/related") {
    return handleGetRelated(request, env, url);
  }
  if (method === "GET" && pathname === "/api/feed") {
    return handleGetFeed(request, env, ctx, url);
  }
  const itemMatch = pathname.match(/^\/api\/item\/(\d+)$/);
  if (method === "GET" && itemMatch) {
    return handleGetItem(request, env, url, Number(itemMatch[1]));
  }
  if (pathname.startsWith("/api/desk/")) {
    return routeDeskApi(request, env, url);
  }
  return jsonError2(404, "Not found.");
}
__name(routeApi, "routeApi");
export {
  index_default as default
};


// Owner email copies. Brevo is only a transport; D1 remains the source of truth.
const CARE_ORIGIN='https://realmwright-care.mdnahin537.workers.dev';
async function readCareJson(request) {
  const reader=request.body?.getReader();
  if (!reader) throw new Error('Empty body');
  const chunks=[];let total=0;
  try {
    while(true){const {value,done}=await reader.read();if(done)break;total+=value.byteLength;
      if(total>65536){await reader.cancel();throw new Error('Body too large');}chunks.push(value);}
  } finally {reader.releaseLock();}
  const bytes=new Uint8Array(total);let offset=0;for(const part of chunks){bytes.set(part,offset);offset+=part.length;}
  const value=JSON.parse(new TextDecoder().decode(bytes));
  if (!value || typeof value!=='object' || Array.isArray(value)) throw new Error('Expected object');
  return value;
}
function careFollowupLabel(payload,f) {return detectGaps(payload).find(q=>q.q===f.q)?.prompt || String(f.q).replace(/_/g,' ');}
function careAnswerLabel(payload,f) {return detectGaps(payload).find(q=>q.q===f.q)?.options.find(o=>o.key===f.a)?.label || String(f.a).replace(/_/g,' ');}
function mailText(value) {return typeof value==='string' && value.length?value:typeof value==='number'?String(value):'Not supplied';}
async function composeCareMail(env,event) {
  const data=JSON.parse(event.snapshot);
  const taxonomy=await loadTaxonomy(env);
  const p=data.payload?JSON.parse(data.payload):{};
  const area=taxonomy.areas.find(a=>a.key===data.area) || (taxonomy.ideaExtraTile.key===data.area?taxonomy.ideaExtraTile:null);
  const areas=(area?.parts || []).flatMap(x=>[x,...(x.children||[])]);
  const label=(list,key)=>list?.find(x=>x.key===key)?.label || (key?String(key).replace(/_/g,' '):'Not supplied');
  const kind=event.kind==='comment'?'COMMENT':event.kind==='followup'?'UPDATED':data.type==='idea'?'IDEA':'BUG';
  const subject=`[RealmWright ${kind}] #${data.itemId} ${mailText(data.title)}`.replace(/[\r\n]/g,' ').slice(0,220);
  const fields={
    _subject:subject,_template:'table',_captcha:'false',
    'Event':event.kind==='followup'?'Additional answers — complete updated report':event.kind==='comment'?'New comment':'New customer submission',
    'Reference':event.event_key,
    'Report':`#${data.itemId}: ${mailText(data.title)}`,
    'Category':data.type==='idea'?'Feature / workflow idea':'Bug report',
    'Area':area?.label || mailText(data.area),
    'Submitted (Bangladesh)':new Date(event.created_at*1000).toLocaleString('en-GB',{timeZone:'Asia/Dhaka',dateStyle:'medium',timeStyle:'long'}),
    'Submitted (UTC)':new Date(event.created_at*1000).toISOString(),
    'Contributor':mailText(data.name || 'A GM'),
    'Reply address':data.email || 'Not supplied — reply on the Customer Care board',
    'Visibility':data.held?'Awaiting owner review':'Public on the Customer Care board',
    'Open report':`${CARE_ORIGIN}/item/?id=${data.itemId}`,
    'Owner Desk':`${CARE_ORIGIN}/desk/`,
  };
  if(event.kind==='comment') {
    fields['Comment']=mailText(data.body);
    fields['In reply to']=data.parentId?`Comment #${data.parentId}`:'Main report';
  } else {
    fields['Submission ID']=String(data.reportId);
    fields['Part']=label(areas,p.part);
    if(data.type==='bug') {
      fields['Symptom']=label([...(taxonomy.symptomsUniversal||[]),...(taxonomy.symptomsByArea?.[data.area]||[])],p.symptom);
      fields['Symptom detail']=mailText(p.symptom_detail?.replace(/_/g,' '));
      fields['Frequency']=label(taxonomy.frequency,p.frequency);
      fields['Expected']=mailText(p.expected);
      fields['Actually happened']=mailText(p.actual);
      fields['Additional details']=mailText(p.freetext || null);
    } else {
      fields['Idea type']=label(taxonomy.ideaKinds,p.ideaKind);
      fields['What it should do']=mailText(p.ask);
      fields['Why it matters']=mailText(p.why);
      fields['What success looks like']=mailText(p.doneLooksLike);
      fields['Importance']=label(taxonomy.importance,p.importance);
    }
    const context=p.ctx||{};
    for(const [key,title] of Object.entries({v:'App version',schema:'Data schema',build:'Build',mode:'Mode',theme:'Theme',ai:'AI setting',os:'Device OS',browser:'Browser',screen:'Screen category',lang:'Language'})) fields[title]=mailText(context[key]);
    fields['Follow-up answers']=(p.followups||[]).map(f=>`${careFollowupLabel(p,f)}: ${careAnswerLabel(p,f)}`).join('\n') || 'None yet';
    // Preserve every accepted original detail alongside the readable summary.
    fields['Original submitted details (complete)']=JSON.stringify(p,null,2);
  }
  fields['About this copy']='The submission remains in Customer Care. This email is an additional copy. Missing details are marked as not supplied; nothing is guessed.';
  return fields;
}
function careEmailHtml(fields) {
  const escape=value=>String(value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  return '<!doctype html><html><body style="margin:0;background:#f5f3ee;font:16px Arial,sans-serif;color:#202020"><div style="max-width:720px;margin:auto;padding:24px"><h1 style="font-size:24px">RealmWright Customer Care</h1><p>A complete copy of the saved submission.</p><table style="border-collapse:collapse;width:100%;background:white">'+Object.entries(fields).filter(([key])=>!key.startsWith('_')).map(([key,value])=>'<tr><th style="text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ddd;width:30%">'+escape(key)+'</th><td style="padding:12px;border-bottom:1px solid #ddd;white-space:pre-wrap;word-break:break-word">'+escape(value)+'</td></tr>').join('')+'</table></div></body></html>';
}
async function deliverCareMail(env,event) {
  if(!env.CARE_MAIL_API_KEY) throw new Error('Email sender needs one-time setup');
  const to=env.CARE_MAIL_TO,from=env.CARE_MAIL_FROM || to;
  if(!to || !from) throw new Error('Email destination is not configured');
  const fields=await composeCareMail(env,event);
  const message={sender:{name:'RealmWright Customer Care',email:from},to:[{email:to,name:'Hunter'}],subject:fields._subject,
    htmlContent:careEmailHtml(fields),textContent:Object.entries(fields).filter(([key])=>!key.startsWith('_')).map(([key,value])=>key+': '+value).join('\n\n'),
    tags:['realmwright-care'],headers:{'X-Care-Event':event.event_key}};
  const email=JSON.parse(event.snapshot).email;
  if(typeof email==='string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))message.replyTo={email};
  const res=await fetch('https://api.brevo.com/v3/smtp/email',{
    method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json','api-key':env.CARE_MAIL_API_KEY},
    body:JSON.stringify(message),signal:AbortSignal.timeout(15000)
  });
  if(!res.ok) throw new Error('Email service returned HTTP '+res.status);
  const result=await res.json();
  if(typeof result.messageId!=='string' || !result.messageId) throw new Error('Email service has not confirmed acceptance');
  return result.messageId;
}
async function drainCareMail(env) {
  if(env.CARE_MAIL_ENABLED!=='true') return;
  const now=Math.floor(Date.now()/1000);
  const {results}=await env.DB.prepare(`SELECT event_key FROM care_mail_outbox
    WHERE (state='pending' AND next_attempt_at<=?1) OR (state='sending' AND lease_until<?1)
    ORDER BY created_at,event_key LIMIT 3`).bind(now).all();
  await Promise.all(results.map(async ({event_key})=>{
    const lease=crypto.randomUUID();
    const row=await env.DB.prepare(`UPDATE care_mail_outbox SET state='sending',lease_token=?1,lease_until=?2,attempts=attempts+1
      WHERE event_key=?3 AND ((state='pending' AND next_attempt_at<=?4) OR (state='sending' AND lease_until<?4)) RETURNING *`)
      .bind(lease,now+120,event_key,now).first();
    if(!row)return;
    try {
      await deliverCareMail(env,row);
      await env.DB.prepare(`UPDATE care_mail_outbox SET state='accepted',accepted_at=?1,last_error=NULL,lease_token=NULL,lease_until=0
        WHERE event_key=?2 AND lease_token=?3`).bind(Math.floor(Date.now()/1000),event_key,lease).run();
    } catch(error) {
      const state=row.attempts>=12?'failed':'pending';
      const delay=Math.min(3600,60*2**Math.min(row.attempts,6));
      await env.DB.prepare(`UPDATE care_mail_outbox SET state=?1,next_attempt_at=?2,last_error=?3,lease_token=NULL,lease_until=0
        WHERE event_key=?4 AND lease_token=?5`).bind(state,now+delay,String(error.message||'Email temporarily unavailable').slice(0,180),event_key,lease).run();
    }
  }));
}

function careContext(value,limit=120){return typeof value==='number' && Number.isFinite(value)?value:typeof value==='string'?(value.trim().slice(0,limit)||null):null;}

const CARE_CLIENT_ASSETS={"/js/wizard.js": "// ★ CROWN JEWEL #1 — the intake wizard (design §5). The interrogation is\n// disguised as navigation: every tap of \"Where? → Which part? → What\n// happened?\" IS the data, so a complete, useful bug report is ≤6 taps and\n// zero keystrokes. Free text is garnish, never the payload. One decision per\n// screen, Back always, Skip wherever text is involved, big tap targets.\n\n(function () {\n  const C = window.Care;\n  const stage = document.getElementById('wiz-stage');\n  const backBtn = document.getElementById('wiz-back');\n  const progressEl = document.getElementById('wiz-progress');\n\n  let me = { loggedIn: false };\n  let taxonomy = null;\n\n  const state = {\n    flow: null, // 'bug' | 'idea'\n    area: null, areaLabel: null,\n    part: null, partLabel: null,\n    symptom: null, symptomLabel: null, symptomDetail: null,\n    frequency: null,\n    kind: null,\n    importance: null,\n    expected: '', actual: '', freetext: '',\n    ask: '', why: '', doneLooksLike: '',\n    title: null, titleEdited: false,\n    ctx: {}, clientCtx: {},\n    joinItemId: null,\n    // for the confirmation screen\n    resultItemId: null, resultReportId: null,\n  };\n\n  let submitting = false;\n  const history = []; // screen-name stack for Back\n\n  // ---- phase mapping for the 4-dot progress strip ----------------------\n  const PHASE = {\n    signin: 0, branch: 0,\n    area: 1, part: 1, symptom: 1, frequency: 1, kind: 1,\n    priorart: 2, write: 2, ask: 2,\n    confirm: 3,\n  };\n  function renderProgress(screen) {\n    const phase = PHASE[screen] ?? 0;\n    progressEl.innerHTML = [0, 1, 2, 3]\n      .map((i) => `<span class=\"dot${i <= phase ? ' dot--on' : ''}\"></span>`)\n      .join('');\n  }\n\n  // ---- context handoff (#ctx fragment) ---------------------------------\n  function parseCtxFragment() {\n    const hash = location.hash || '';\n    const m = hash.match(/[#&]ctx=([^&]+)/);\n    if (!m) return {};\n    try {\n      const b64 = m[1].replace(/-/g, '+').replace(/_/g, '/');\n      const pad = b64.length % 4 ? '='.repeat(4 - (b64.length % 4)) : '';\n      return JSON.parse(decodeURIComponent(escape(atob(b64 + pad))));\n    } catch {\n      try {\n        // simpler decode path if the above escape() route fails\n        return JSON.parse(atob(m[1].replace(/-/g, '+').replace(/_/g, '/')));\n      } catch {\n        return {};\n      }\n    }\n  }\n  function collectClientCtx() {\n    const ua = navigator.userAgent || '';\n    let os = 'other';\n    if (/Windows/i.test(ua)) os = 'windows';\n    else if (/Mac OS X|Macintosh/i.test(ua)) os = 'mac';\n    else if (/Android/i.test(ua)) os = 'android';\n    else if (/iPhone|iPad|iPod/i.test(ua)) os = 'ios';\n    else if (/Linux/i.test(ua)) os = 'linux';\n    let browser = 'other';\n    if (/Edg\\//i.test(ua)) browser = 'edge';\n    else if (/Chrome\\//i.test(ua)) browser = 'chrome';\n    else if (/Firefox\\//i.test(ua)) browser = 'firefox';\n    else if (/Safari\\//i.test(ua) && !/Chrome/i.test(ua)) browser = 'safari';\n    const w = window.innerWidth;\n    const screen = w < 600 ? 'phone' : w < 1024 ? 'tablet' : 'desktop';\n    return { os, browser, screen, lang: (navigator.language || 'en').slice(0, 5) };\n  }\n\n  // ---- title composer (mirror of server lib/titles.js) -----------------\n  const SYMPTOM_SHORT = {\n    nothing_happened: \"didn't respond to a click\", wrong_thing: 'did the wrong thing',\n    work_disappeared: \"work didn't save\", display_broken: 'display looks broken',\n    froze_crashed: 'froze or crashed', slow: 'running slow', error_message: 'showed an error',\n    something_else: 'something felt off', ai_wrong_answer: 'AI gave a bad answer', ai_call_failed: 'AI call failed',\n    wont_import: \"file wouldn't import\", pdf_missing_content: 'PDF missing content', license_wont_activate: \"license won't activate\",\n  };\n  const FREQ_LABEL = { every_time: 'every time', sometimes: 'sometimes', once: 'once' };\n  function composeTitle() {\n    if (state.flow === 'bug') {\n      const sym = SYMPTOM_SHORT[state.symptom] || 'something went wrong';\n      const f = FREQ_LABEL[state.frequency];\n      return f ? `${state.areaLabel} — ${sym} (${f})` : `${state.areaLabel} — ${sym}`;\n    }\n    const ask = (state.ask || '').trim();\n    if (ask) return `${state.areaLabel} — ${ask.length > 70 ? ask.slice(0, 67) + '…' : ask}`;\n    return `${state.areaLabel} — new idea`;\n  }\n\n  // ---- navigation ------------------------------------------------------\n  function goTo(screen, { push = true } = {}) {\n    if (push && history[history.length - 1] !== screen) history.push(screen);\n    backBtn.hidden = history.length <= 1 || screen === 'confirm';\n    renderProgress(screen);\n    RENDER[screen]();\n    stage.scrollTop = 0;\n  }\n  function back() {\n    if (history.length <= 1) return;\n    history.pop();\n    const prev = history[history.length - 1];\n    goTo(prev, { push: false });\n  }\n  backBtn.addEventListener('click', back);\n\n  // ---- screen builders (return DOM string; wire after inject) ----------\n  function screen(html) { stage.innerHTML = html; }\n\n  function tileGrid(items, onPick, { extraFirst } = {}) {\n    const all = extraFirst ? [extraFirst, ...items] : items;\n    const grid = document.createElement('div');\n    grid.className = 'tilegrid';\n    for (const it of all) {\n      const b = document.createElement('button');\n      b.className = 'tile';\n      b.innerHTML =\n        `<span class=\"tile__icon\" aria-hidden=\"true\">${icon(it.icon)}</span>` +\n        `<span class=\"tile__label\">${C.esc(it.label)}</span>`;\n      b.addEventListener('click', () => onPick(it));\n      grid.appendChild(b);\n    }\n    return grid;\n  }\n  // Minimal inline icon set (no icon-font dependency) — a small glyph per area.\n  function icon() { return '◆'; }\n\n  function chipList(items, onPick) {\n    const wrap = document.createElement('div');\n    wrap.className = 'choicechips';\n    for (const it of items) {\n      const b = document.createElement('button');\n      b.className = 'choicechip';\n      b.textContent = it.label;\n      b.addEventListener('click', () => onPick(it, b));\n      wrap.appendChild(b);\n    }\n    return wrap;\n  }\n\n  function heading(text, sub) {\n    return `<h1 class=\"wiz__h\">${C.esc(text)}</h1>` + (sub ? `<p class=\"wiz__sub\">${C.esc(sub)}</p>` : '');\n  }\n  function skipRow(label, onSkip) {\n    const div = document.createElement('div');\n    div.className = 'wiz__skip';\n    const b = document.createElement('button');\n    b.className = 'linkbtn';\n    b.textContent = label || 'Skip';\n    b.addEventListener('click', onSkip);\n    div.appendChild(b);\n    return div;\n  }\n\n  // ---- RENDERERS -------------------------------------------------------\n  const RENDER = {};\n\n  RENDER.signin = function () {\n    screen(\n      '<div class=\"wiz__screen wiz__center\">' +\n      '<div class=\"wiz__mark mono\">RW</div>' +\n      heading('Tell Hunter what you found', 'Use this device to keep track of your reports. Reports are public; no email address is required.') +\n      '<button class=\"btn btn-primary btn--big\" id=\"wiz-continue\">Continue to Care</button>' +\n      '<p class=\"wiz__fine\">One quick step, then it’s all taps.</p>' +\n      '</div>'\n    );\n    document.getElementById('wiz-continue').addEventListener('click', () => {\n      // preserve the #ctx fragment while the local Care identity is created\n      C.login(location.pathname + location.search + location.hash);\n    });\n  };\n\n  RENDER.branch = function () {\n    screen('<div class=\"wiz__screen\">' + heading('What brings you here?', 'One tap to start.') + '<div id=\"branch-slot\"></div></div>');\n    const grid = tileGrid(\n      [\n        { key: 'bug', label: 'Something’s broken', icon: 'bug' },\n        { key: 'idea', label: 'I have an idea', icon: 'idea' },\n      ],\n      (it) => {\n        state.flow = it.key; state.joinItemId=null; state.titleEdited=false; state.title=null;\n        goTo('area');\n      }\n    );\n    grid.classList.add('tilegrid--two');\n    document.getElementById('branch-slot').appendChild(grid);\n  };\n\n  RENDER.area = function () {\n    const isIdea = state.flow === 'idea';\n    const title = isIdea ? 'What’s it about?' : 'Where were you?';\n    const sub = isIdea ? 'Pick the closest area — or something brand new.' : 'Pick the part of RealmWright where it happened.';\n    screen('<div class=\"wiz__screen\">' + heading(title, sub) + '<div id=\"area-slot\"></div></div>');\n    const extraFirst = isIdea ? { key: taxonomy.ideaExtraTile.key, label: taxonomy.ideaExtraTile.label, icon: taxonomy.ideaExtraTile.icon } : null;\n    const grid = tileGrid(taxonomy.areas, (it) => {\n      state.area = it.key; state.areaLabel = it.label; state.joinItemId=null; state.titleEdited=false; state.title=null;\n      state.part = null; state.partLabel = null;\n      if (isIdea) {\n        goTo('kind');\n      } else if (it.key === 'other') {\n        goTo('symptom'); // \"not sure\" skips the part step\n      } else {\n        goTo('part');\n      }\n    }, { extraFirst });\n    // handle the idea \"new\" tile specially\n    if (extraFirst) {\n      grid.firstChild.addEventListener('click', () => {\n        state.area = extraFirst.key; state.areaLabel = extraFirst.label; state.part = null;\n        goTo('kind');\n      }, true);\n    }\n    document.getElementById('area-slot').appendChild(grid);\n  };\n\n  RENDER.part = function () {\n    const areaObj = taxonomy.areas.find((a) => a.key === state.area);\n    const parts = (areaObj && areaObj.parts) || [];\n    const items = parts.map((p) => ({ key: p.key, label: p.label, children: p.children }))\n      .concat([{ key: null, label: 'Not sure' }]);\n    screen('<div class=\"wiz__screen\">' + heading('Which part?', 'Closest one is fine.') + '<div id=\"part-slot\"></div></div>');\n    const list = chipList(items, (it) => {\n      state.part = it.key; state.partLabel = it.label;\n      if (it.children && it.children.length) {\n        renderSubPart(it);\n      } else {\n        goTo('symptom');\n      }\n    });\n    document.getElementById('part-slot').appendChild(list);\n  };\n  function renderSubPart(parent) {\n    screen('<div class=\"wiz__screen\">' + heading(parent.label, 'Which one?') + '<div id=\"subpart-slot\"></div></div>');\n    const items = parent.children.map((c) => ({ key: c.key, label: c.label })).concat([{ key: parent.key, label: 'Not sure' }]);\n    const list = chipList(items, (it) => {\n      state.part = it.key; state.partLabel = it.label;\n      goTo('symptom');\n    });\n    document.getElementById('subpart-slot').appendChild(list);\n    // Back from a sub-part returns to the part list, not the area\n    history.push('part');\n    backBtn.hidden = false;\n  }\n\n  RENDER.symptom = function () {\n    const universal = taxonomy.symptomsUniversal;\n    const areaSpecific = (taxonomy.symptomsByArea && taxonomy.symptomsByArea[state.area]) || [];\n    const items = [...universal, ...areaSpecific];\n    screen('<div class=\"wiz__screen\">' + heading('What happened?', 'The closest description.') + '<div id=\"sym-slot\"></div></div>');\n    const list = chipList(items, (it, btn) => {\n      state.symptom = it.key; state.symptomLabel = it.label;\n      state.symptomDetail = null;\n      if (it.followups && it.followups.length) {\n        revealSymptomFollowup(it, btn);\n      } else {\n        goTo('frequency');\n      }\n    });\n    document.getElementById('sym-slot').appendChild(list);\n  };\n  function revealSymptomFollowup(sym, btn) {\n    // inline follow-up row (not a new screen), per §5.2 B3\n    btn.classList.add('is-active');\n    const existing = document.querySelector('.symptom-followup');\n    if (existing) existing.remove();\n    const row = document.createElement('div');\n    row.className = 'symptom-followup';\n    row.innerHTML = '<p class=\"wiz__inline-q\">When?</p>';\n    const list = chipList(sym.followups.map((f) => ({ key: f.key, label: f.label })), (it) => {\n      state.symptomDetail = it.key;\n      goTo('frequency');\n    });\n    row.appendChild(list);\n    btn.parentElement.insertAdjacentElement('afterend', row);\n    row.scrollIntoView({ block: 'nearest' });\n  }\n\n  RENDER.frequency = function () {\n    screen('<div class=\"wiz__screen\">' + heading('How often?', 'Last one before we check for matches.') + '<div id=\"freq-slot\"></div></div>');\n    const list = chipList(taxonomy.frequency, (it) => {\n      state.frequency = it.key;\n      goToPriorArt();\n    });\n    document.getElementById('freq-slot').appendChild(list);\n  };\n\n  RENDER.kind = function () {\n    screen('<div class=\"wiz__screen\">' + heading('What kind of idea?', 'Pick one.') + '<div id=\"kind-slot\"></div></div>');\n    const list = chipList(taxonomy.ideaKinds, (it) => {\n      state.kind = it.key;\n      goToPriorArt();\n    });\n    document.getElementById('kind-slot').appendChild(list);\n  };\n\n  // ---- prior art (B5 / I3): fetch matches, offer join ------------------\n  async function goToPriorArt() {\n    // fetch in the background; if none, skip silently to the write/ask screen\n    let matches = [];\n    try {\n      const p = new URLSearchParams({ type: state.flow, area: state.area });\n      if (state.part) p.set('part', state.part);\n      const res = await fetch('/api/related?' + p.toString());\n      const data = await res.json();\n      matches = data.items || [];\n    } catch { matches = []; }\n    if (matches.length === 0) {\n      goTo(state.flow === 'bug' ? 'write' : 'ask');\n      return;\n    }\n    state._matches = matches;\n    goTo('priorart');\n  }\n\n  RENDER.priorart = function () {\n    const matches = state._matches || [];\n    const rows = matches.map((m) =>\n      '<button class=\"priorart__row\" data-id=\"' + m.id + '\">' +\n      '<span class=\"priorart__serial mono\">#' + m.id + '</span>' +\n      '<span class=\"priorart__body\"><span class=\"priorart__title\">' + C.esc(m.title) + '</span>' +\n      '<span class=\"priorart__meta\">' + (m.reportsCount === 1 ? '1 GM' : m.reportsCount + ' GMs') + ' · ' + statusLabel(m.status) + '</span></span>' +\n      '<span class=\"priorart__join\">This is mine →</span>' +\n      '</button>'\n    ).join('');\n    screen(\n      '<div class=\"wiz__screen\">' +\n      heading('GMs already reported these', 'Tap one if it’s the same — your voice adds to it.') +\n      '<div class=\"priorart\">' + rows + '</div>' +\n      '<div class=\"wiz__actions\"><button class=\"btn\" id=\"mine-different\">Mine is different</button></div>' +\n      '</div>'\n    );\n    stage.querySelectorAll('.priorart__row').forEach((row) => {\n      row.addEventListener('click', () => joinItem(Number(row.dataset.id)));\n    });\n    document.getElementById('mine-different').addEventListener('click', () => {\n      state.joinItemId = null;\n      goTo(state.flow === 'bug' ? 'write' : 'ask');\n    });\n  };\n\n  async function joinItem(itemId) {\n    state.joinItemId = itemId;\n    goTo(state.flow === 'bug' ? 'write' : 'ask');\n  }\n\n  // ---- write (B6, bug) -------------------------------------------------\n  RENDER.write = function () {\n    state.title = state.titleEdited ? state.title : composeTitle();\n    screen(\n      '<div class=\"wiz__screen\">' +\n      heading('Anything to add?', 'All optional — your taps already told the story.') +\n      '<div class=\"writefields\">' +\n      field('expected', 'What did you expect?', state.expected) +\n      field('actual', 'What actually happened?', state.actual) +\n      textarea('freetext', 'Anything else, in your own words', state.freetext) +\n      '</div>' +\n      contextCard() +\n      titlePreview() +\n      '<div class=\"wiz__actions\"><button class=\"btn btn-primary btn--big\" id=\"send\">Send report</button></div>' +\n      '</div>'\n    );\n    wireWriteScreen();\n  };\n\n  // ---- ask (I4, idea) --------------------------------------------------\n  RENDER.ask = function () {\n    state.title = state.titleEdited ? state.title : composeTitle();\n    screen(\n      '<div class=\"wiz__screen\">' +\n      heading('What’s the idea?', 'One line is plenty. The rest is optional.') +\n      '<div class=\"writefields\">' +\n      field('ask', 'What should it do?', state.ask, 'Let me export just one faction as its own PDF') +\n      field('why', 'What would it let you do at your table? (optional)', state.why) +\n      field('doneLooksLike', 'What does “done” look like? (optional)', state.doneLooksLike) +\n      '</div>' +\n      '<div class=\"importance\"><p class=\"wiz__inline-q\">How much would you use it?</p><div id=\"imp-slot\"></div></div>' +\n      contextCard() +\n      titlePreview() +\n      '<div class=\"wiz__actions\"><button class=\"btn btn-primary btn--big\" id=\"send\">Send idea</button></div>' +\n      '</div>'\n    );\n    const impList = chipList(taxonomy.importance, (it, btn) => {\n      state.importance = it.key;\n      impList.querySelectorAll('.choicechip').forEach((c) => c.classList.remove('is-active'));\n      btn.classList.add('is-active');\n    });\n    if (state.importance) {\n      const idx = taxonomy.importance.findIndex((i) => i.key === state.importance);\n      if (idx >= 0) impList.children[idx].classList.add('is-active');\n    }\n    document.getElementById('imp-slot').appendChild(impList);\n    wireWriteScreen();\n  };\n\n  function field(name, label, value, placeholder) {\n    return (\n      '<label class=\"wfield\"><span class=\"wfield__label\">' + C.esc(label) + '</span>' +\n      '<input class=\"wfield__input\" data-field=\"' + name + '\" value=\"' + C.esc(value || '') + '\"' +\n      (placeholder ? ' placeholder=\"' + C.esc(placeholder) + '\"' : '') + ' maxlength=\"300\"></label>'\n    );\n  }\n  function textarea(name, label, value) {\n    return (\n      '<label class=\"wfield\"><span class=\"wfield__label\">' + C.esc(label) + '</span>' +\n      '<textarea class=\"wfield__input wfield__area\" data-field=\"' + name + '\" rows=\"2\" maxlength=\"2000\">' + C.esc(value || '') + '</textarea></label>'\n    );\n  }\n\n  function contextCard() {\n    const rows = ctxRows();\n    if (rows.length === 0) return '';\n    return (\n      '<div class=\"ctxcard\" id=\"ctxcard\">' +\n      '<div class=\"ctxcard__head\">Attached so Hunter can reproduce this</div>' +\n      '<div class=\"ctxcard__rows\">' +\n      rows.map((r) => '<span class=\"ctxpill\" data-key=\"' + r.key + '\">' + C.esc(r.label) +\n        '<button class=\"ctxpill__x\" aria-label=\"Remove ' + C.esc(r.label) + '\">✕</button></span>').join('') +\n      '</div>' +\n      '<div class=\"ctxcard__note\">Sending to RealmWright’s community server.</div>' +\n      '</div>'\n    );\n  }\n  function ctxRows() {\n    const rows = [];\n    const push = (key, label) => { if (label) rows.push({ key, label }); };\n    push('v', state.ctx.v && ('v' + state.ctx.v));\n    push('build', state.ctx.build && (state.ctx.build === 'demo' ? 'Demo build' : 'Full build'));\n    push('mode', state.ctx.mode && (cap(state.ctx.mode) + ' mode'));\n    push('theme', state.ctx.theme && cap(state.ctx.theme));\n    push('ai', state.ctx.ai && (state.ctx.ai === 'none' ? 'No AI' : cap(state.ctx.ai)));\n    push('os', state.clientCtx.os && cap(state.clientCtx.os));\n    push('browser', state.clientCtx.browser && cap(state.clientCtx.browser));\n    push('screen', state.clientCtx.screen && cap(state.clientCtx.screen));\n    // filter out the ones the user removed\n    return rows.filter((r) => !removedCtx.has(r.key));\n  }\n  const removedCtx = new Set();\n  function cap(s) { return s ? String(s).charAt(0).toUpperCase() + String(s).slice(1) : s; }\n\n  function titlePreview() {\n    const t = state.title || composeTitle();\n    return (\n      '<div class=\"titleprev\"><span class=\"titleprev__label\">Title (tap to edit)</span>' +\n      '<input class=\"titleprev__input\" id=\"title-input\" value=\"' + C.esc(t) + '\" maxlength=\"300\"></div>'\n    );\n  }\n\n  function wireWriteScreen() {\n    stage.querySelectorAll('[data-field]').forEach((el) => {\n      el.addEventListener('input', () => {\n        state[el.dataset.field] = el.value;\n        if (!state.titleEdited) {\n          const ti = document.getElementById('title-input');\n          if (ti) ti.value = composeTitle();\n        }\n      });\n    });\n    const ti = document.getElementById('title-input');\n    if (ti) ti.addEventListener('input', () => { state.titleEdited = true; state.title = ti.value; });\n    stage.querySelectorAll('.ctxpill__x').forEach((x) => {\n      x.addEventListener('click', (e) => {\n        e.preventDefault();\n        const key = x.closest('.ctxpill').dataset.key;\n        removedCtx.add(key);\n        const card = document.getElementById('ctxcard');\n        const fresh = document.createElement('div');\n        fresh.innerHTML = contextCard();\n        if (card) {\n          if (fresh.firstChild) card.replaceWith(fresh.firstChild); else card.remove();\n          // rewire the new card's remove buttons\n          stage.querySelectorAll('.ctxpill__x').forEach((nx) => {\n            nx.addEventListener('click', (ev) => {\n              ev.preventDefault();\n              removedCtx.add(nx.closest('.ctxpill').dataset.key);\n              RENDER[state.flow === 'bug' ? 'write' : 'ask']();\n            });\n          });\n        }\n      });\n    });\n    const send = document.getElementById('send');\n    if (send) send.addEventListener('click', () => submitReport(!!state.joinItemId));\n  }\n\n  // ---- submit ----------------------------------------------------------\n  async function submitReport(isJoin) {\n    if (submitting) return;\n    if (state.flow==='idea' && !isJoin && !state.ask.trim()) {showError('Tell Hunter what the idea should do.');return;}\n    submitting=true;\n    const btn = document.getElementById('send');\n    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }\n\n    const filteredCtx = {};\n    for (const [k, v] of Object.entries(state.ctx)) if (!removedCtx.has(k)) filteredCtx[k] = v;\n    const filteredClientCtx = {};\n    for (const [k, v] of Object.entries(state.clientCtx)) if (!removedCtx.has(k)) filteredClientCtx[k] = v;\n\n    const payload = {\n      mode: isJoin ? 'join' : 'create', joinItemId: isJoin ? state.joinItemId : undefined,\n      type: state.flow, area: state.area, part: state.part,\n      symptom: state.symptom, symptomDetail: state.symptomDetail, frequency: state.frequency,\n      expected: state.expected, actual: state.actual, freetext: state.freetext,\n      ideaKind: state.kind, ask: state.ask, why: state.why, doneLooksLike: state.doneLooksLike,\n      importance: state.importance, title: state.titleEdited ? state.title : undefined,\n      ctx: filteredCtx, clientCtx: filteredClientCtx,\n    };\n\n    let data;\n    try {\n      const res = await fetch('/api/report', {\n        method: 'POST', headers: { 'Content-Type': 'application/json' },\n        body: JSON.stringify(payload),\n      });\n      data = await res.json();\n      if (!res.ok) throw new Error(data.error || 'Send failed');\n    } catch (err) {\n      submitting=false;\n      if (btn) { btn.disabled = false; btn.textContent = state.flow === 'bug' ? 'Send report' : 'Send idea'; }\n      showError(err.message);\n      return;\n    }\n    submitting=false;\n    state.resultHeld=!!data.held;\n    state.resultItemId = data.itemId;\n    state.resultReportId = data.reportId || null;\n    goTo('confirm');\n  }\n\n  function showError(msg) {\n    const el = document.createElement('div');\n    el.className = 'wiz__error';\n    el.textContent = msg || 'Something went wrong — please try again.';\n    stage.querySelector('.wiz__screen')?.prepend(el);\n  }\n\n  // ---- confirmation + micro-interview (B7 / I5) ------------------------\n  RENDER.confirm = function () {\n    const id = state.resultItemId;\n    screen(\n      '<div class=\"wiz__screen wiz__center\">' +\n      '<div class=\"confirm__check\" aria-hidden=\"true\">✓</div>' +\n      '<h1 class=\"wiz__h\">Filed as <span class=\"mono\">#' + id + '</span></h1>' +\n      '<p class=\"wiz__sub\">' + (state.resultHeld ? 'Saved for Hunter to review before it appears on the board.' : 'Saved to Customer Care. GMs can find it, discuss it and vote.') + '</p>' +\n      '<div id=\"micro-slot\"></div>' +\n      '<div class=\"confirm__actions\">' +\n      (state.resultHeld ? '' : '<a class=\"btn btn-primary\" href=\"/item/?id=' + id + '\">Watch #' + id + '</a>') +\n      '<a class=\"btn\" href=\"/\">Back to the board</a>' +\n      '</div>' +\n      '</div>'\n    );\n    backBtn.hidden = true;\n    maybeAskMicroInterview();\n  };\n\n  async function maybeAskMicroInterview() {\n    // Both the create and the join response always include the new report's\n    // id (report.js returns reportId on both paths), stashed here as\n    // state.resultReportId by submitReport. If it's somehow absent, skip\n    // gracefully — the confirmation is already on screen and the\n    // micro-interview must never block it.\n    const reportId = state.resultReportId || null;\n    if (!reportId) return; // nothing to enrich; confirmation already complete\n    let asked = 0;\n    await askOne(reportId);\n\n    async function askOne(reportId) {\n      if (asked >= 2) return;\n      let q = null;\n      try {\n        const res = await fetch('/api/report/' + reportId + '/followup-question');\n        const data = await res.json();\n        q = data.question;\n      } catch { q = null; }\n      if (!q) return; // AI down or no gap → nothing extra shows (instant, never blocks)\n      renderMicro(q, reportId);\n    }\n\n    function renderMicro(q, reportId) {\n      const slot = document.getElementById('micro-slot');\n      if (!slot) return;\n      const box = document.createElement('div');\n      box.className = 'micro';\n      box.innerHTML = '<p class=\"micro__q\">One more tap helps Hunter fix this faster (optional):</p>' +\n        '<p class=\"micro__prompt\">' + C.esc(q.prompt) + '</p>';\n      const opts = document.createElement('div');\n      opts.className = 'micro__opts';\n      for (const o of q.options) {\n        const b = document.createElement('button');\n        b.className = 'choicechip';\n        b.textContent = o.label;\n        b.addEventListener('click', async () => {\n          asked += 1;\n          opts.querySelectorAll('button').forEach((x) => (x.disabled = true));\n          b.classList.add('is-active');\n          try {\n            const saved=await fetch('/api/report/' + reportId + '/followup', {\n              method: 'PATCH', headers: { 'Content-Type': 'application/json' },\n              body: JSON.stringify({ q: q.q, a: o.key }),\n            });\n            if (!saved.ok) throw new Error('Answer was not saved.');\n          } catch {\n            asked-=1; opts.querySelectorAll('button').forEach(x=>x.disabled=false);\n            b.classList.remove('is-active');\n            if (!box.querySelector('[role=\"alert\"]')) {const error=document.createElement('p');error.setAttribute('role','alert');error.textContent='Could not save that answer. Please try again.';box.appendChild(error);}\n            return;\n          }\n          box.remove();\n          await askOne(reportId); // maybe one more (max 2)\n        });\n        opts.appendChild(b);\n      }\n      const skip = document.createElement('button');\n      skip.className = 'linkbtn micro__skip';\n      skip.textContent = 'Skip';\n      skip.addEventListener('click', () => box.remove());\n      box.appendChild(opts);\n      box.appendChild(skip);\n      slot.appendChild(box);\n    }\n  }\n\n  function statusLabel(s) { return C.STATUS_LABEL[s] || s; }\n\n  // ---- init ------------------------------------------------------------\n  async function init() {\n    state.ctx = parseCtxFragment();\n    state.clientCtx = collectClientCtx();\n\n    const [meRes, taxRes] = await Promise.all([\n      C.getMe(),\n      fetch('/data/taxonomy.json').then((r) => r.json()).catch(() => null),\n    ]);\n    me = meRes; taxonomy = taxRes;\n\n    if (!taxonomy) {\n      stage.innerHTML = '<div class=\"wiz__screen wiz__center\"><p>Couldn’t load the form. <a href=\"/\">Back to the board</a></p></div>';\n      return;\n    }\n\n    if (!me.loggedIn) {\n      goTo('signin');\n    } else {\n      goTo('branch');\n    }\n  }\n\n  init();\n})();\n", "/js/board.js": "// The public board (design §6, §8). Renders the shipped strip and one woven\n// feed with serials/tags/status chips;\n// filters, search, sort toggle, pagination; inline agree/disagree with\n// login-on-first-tap and post-login replay at the same scroll position.\n\n(function () {\n  const C = window.Care;\n  const feedList = document.getElementById('feed-list');\n  const feedEmpty = document.getElementById('feed-empty');\n  const feedLoading = document.getElementById('feed-loading');\n  const loadMoreBtn = document.getElementById('load-more');\n  const shippedSection = document.getElementById('shipped');\n  const shippedList = document.getElementById('shipped-list');\n\n  let me = { loggedIn: false };\n  let state = { area: '', type: '', status: '', q: '', sort: 'woven', page: 0 };\n  let taxonomy = null;\n  let loadedItems = []; // accumulated across pages\n\n  // ---- URL <-> state ---------------------------------------------------\n  function readStateFromUrl() {\n    const p = new URLSearchParams(location.search);\n    state.area = p.get('area') || '';\n    state.type = p.get('type') || '';\n    state.status = p.get('status') || '';\n    state.q = p.get('q') || '';\n    state.sort = p.get('sort') === 'newest' ? 'newest' : 'woven';\n    state.page = 0;\n  }\n  function writeStateToUrl() {\n    const p = new URLSearchParams();\n    if (state.area) p.set('area', state.area);\n    if (state.type) p.set('type', state.type);\n    if (state.status) p.set('status', state.status);\n    if (state.q) p.set('q', state.q);\n    if (state.sort === 'newest') p.set('sort', 'newest');\n    const qs = p.toString();\n    history.replaceState(null, '', qs ? '?' + qs : location.pathname);\n  }\n\n  function feedUrl(page) {\n    const p = new URLSearchParams();\n    if (state.area) p.set('area', state.area);\n    if (state.type) p.set('type', state.type);\n    if (state.status) p.set('status', state.status);\n    if (state.q) p.set('q', state.q);\n    if (state.sort === 'newest') p.set('sort', 'newest');\n    p.set('page', String(page));\n    return '/api/feed?' + p.toString();\n  }\n\n  // ---- rendering -------------------------------------------------------\n  function itemHref(id) { return '/item/?id=' + id; }\n\n  function tagStamp(tag) {\n    if (!tag) return '';\n    return '<span class=\"tag tag-' + tag + '\">' + C.TAG_LABEL[tag] + '</span>';\n  }\n  function statusChip(status) {\n    if (status === 'open') return ''; // \"open\" is the default; no chip needed\n    return '<span class=\"chip status-' + status + '\">' + C.STATUS_LABEL[status] + '</span>';\n  }\n\n  function voteControls(item) {\n    const mine = item._myVote || 0;\n    return (\n      '<div class=\"vote\" data-item=\"' + item.id + '\">' +\n      '<button class=\"vote__btn vote__up' + (mine === 1 ? ' is-on' : '') + '\" data-val=\"1\" aria-pressed=\"' + (mine === 1) + '\" title=\"Agree — I want this too\">' +\n      '<span aria-hidden=\"true\">▲</span></button>' +\n      '<span class=\"vote__net mono\" aria-label=\"' + item.net + ' net agreement\">' + item.net + '</span>' +\n      '<button class=\"vote__btn vote__down' + (mine === -1 ? ' is-on' : '') + '\" data-val=\"-1\" aria-pressed=\"' + (mine === -1) + '\" title=\"Disagree\">' +\n      '<span aria-hidden=\"true\">▼</span></button>' +\n      '</div>'\n    );\n  }\n\n  function areaLabel(key) {\n    if (!taxonomy) return key;\n    const a = taxonomy.areas.find((x) => x.key === key);\n    if (a) return a.label;\n    if (taxonomy.ideaExtraTile.key === key) return taxonomy.ideaExtraTile.label;\n    return key;\n  }\n\n  function feedRow(item) {\n    const gms = item.reportsCount === 1 ? '1 GM' : item.reportsCount + ' GMs';\n    return (\n      '<article class=\"row\" id=\"item-' + item.id + '\">' +\n      voteControls(item) +\n      '<a class=\"row__main\" href=\"' + itemHref(item.id) + '\">' +\n      '<span class=\"row__serial mono\">#' + item.id + '</span>' +\n      '<span class=\"row__body\">' +\n      '<span class=\"row__title\">' + C.esc(item.title) + '</span>' +\n      '<span class=\"row__meta\">' +\n      tagStamp(item.tag) + statusChip(item.status) +\n      '<span class=\"row__area\">' + C.esc(areaLabel(item.area)) + '</span>' +\n      '<span class=\"row__dot\">·</span>' +\n      '<span class=\"row__reports\">' + gms + '</span>' +\n      (item.commentsCount ? '<span class=\"row__dot\">·</span><span class=\"row__comments\">' + item.commentsCount + ' comment' + (item.commentsCount === 1 ? '' : 's') + '</span>' : '') +\n      '</span>' +\n      (item.ownerNote ? '<span class=\"row__ownernote\">' + C.esc(item.ownerNote) + '</span>' : '') +\n      '</span>' +\n      '</a>' +\n      '</article>'\n    );\n  }\n\n  function shippedCard(item) {\n    return (\n      '<a class=\"shipcard\" href=\"' + itemHref(item.id) + '\">' +\n      '<span class=\"shipcard__serial mono\">#' + item.id + '</span>' +\n      '<span class=\"shipcard__title\">' + C.esc(item.title) + '</span>' +\n      (item.ownerNote ? '<span class=\"shipcard__note\">' + C.esc(item.ownerNote) + '</span>' : '') +\n      '</a>'\n    );\n  }\n\n  function emptyStateHtml() {\n    if (state.q || state.area || state.type || state.status) {\n      return '<h2>Nothing matches that yet</h2><p>Try clearing a filter, or be the first to report it.</p>' +\n        '<a class=\"btn btn-primary\" href=\"/report/\">Report a problem or idea</a>';\n    }\n    return '<h2>Be the first to shape what gets built next</h2>' +\n      '<p>This board is brand new. Report a bug or ask for a feature and it starts right here.</p>' +\n      '<a class=\"btn btn-primary\" href=\"/report/\">Report a problem or idea</a>';\n  }\n\n  // ---- data ------------------------------------------------------------\n  async function loadFeed(reset) {\n    if (reset) {\n      state.page = 0;\n      loadedItems = [];\n      feedList.innerHTML = '';\n      feedEmpty.hidden = true;\n    }\n    feedLoading.hidden = false;\n    loadMoreBtn.hidden = true;\n\n    let data;\n    try {\n      const res = await fetch(feedUrl(state.page), { headers: { Accept: 'application/json' } });\n      if (!res.ok) throw new Error('Board unavailable');\n      data = await res.json();\n      if (!Array.isArray(data.items)) throw new Error('Board unavailable');\n    } catch {\n      feedLoading.hidden = true;\n      feedEmpty.hidden = false;\n      feedEmpty.innerHTML = '<h2>The board is catching its breath</h2><p>Live data will be back shortly.</p>';\n      return;\n    }\n    feedLoading.hidden = true;\n\n    // /api/feed never carries per-user data (it's the shared edge cache) —\n    // the viewer's own vote is reflected afterwards by syncMyVotes() below.\n    if (state.page === 0) renderShipped(data);\n\n    for (const it of data.items) loadedItems.push(it);\n    if (state.page === 0 && data.items.length === 0) {\n      feedEmpty.hidden = false;\n      feedEmpty.innerHTML = emptyStateHtml();\n    } else {\n      feedList.insertAdjacentHTML('beforeend', data.items.map(feedRow).join(''));\n    }\n    loadMoreBtn.hidden = !data.hasMore;\n\n    // Reflect the viewer's own vote (button highlighted, no arithmetic —\n    // the net shown already includes it) on exactly the rows THIS call\n    // just rendered — never the whole accumulated `loadedItems` list, so\n    // the id list stays small regardless of how many pages are loaded.\n    // Shipped cards carry no vote UI.\n    const newIds = data.items.map((it) => it.id);\n    await syncMyVotes(newIds, data.generatedAt);\n  }\n  function renderShipped(data) {\n    if (!data.shipped || !data.shipped.length) {\n      shippedSection.hidden = true;\n      return;\n    }\n    shippedSection.hidden = false;\n    shippedList.innerHTML = data.shipped.map(shippedCard).join('');\n  }\n\n  // ---- voting (optimistic + login-on-first-tap) ------------------------\n  async function handleVoteClick(e) {\n    const btn = e.target.closest('.vote__btn');\n    if (!btn) return;\n    e.preventDefault();\n    const wrap = btn.closest('.vote');\n    const itemId = Number(wrap.dataset.item);\n    const val = Number(btn.dataset.val);\n\n    if (!me.loggedIn) {\n      // Save intent, then create or recover the local Care identity and return to this exact spot.\n      C.stashPending({ kind: 'vote', itemId, value: val, scrollTo: 'item-' + itemId });\n      C.login(location.pathname + location.search + '#item-' + itemId);\n      return;\n    }\n\n    // Determine the toggle: pressing the on-button again clears the vote.\n    if (wrap.dataset.saving==='1') return;\n    wrap.dataset.saving='1';\n    const previous=wrap.querySelector('[data-val=\"1\"]').classList.contains('is-on')?1:wrap.querySelector('[data-val=\"-1\"]').classList.contains('is-on')?-1:0;\n    const currentlyOn = btn.classList.contains('is-on');\n    const newValue = currentlyOn ? 0 : val;\n    applyVoteToDom(wrap, newValue);\n\n    let result; try {result=await C.vote(itemId,newValue);} catch {result={ok:false,status:0,body:{}};} finally {delete wrap.dataset.saving;}\n    if (!result.ok) {\n      // revert on failure\n      applyVoteToDom(wrap, previous);\n      if (result.status === 429) alert(result.body.error || 'You have hit today’s limit.');\n    } else if (typeof result.body.net==='number') {wrap.querySelector('.vote__net').textContent=result.body.net;}\n  }\n\n  function applyVoteToDom(wrap, newValue) {\n    const up = wrap.querySelector('.vote__up');\n    const down = wrap.querySelector('.vote__down');\n    const netEl = wrap.querySelector('.vote__net');\n    const prev = up.classList.contains('is-on') ? 1 : down.classList.contains('is-on') ? -1 : 0;\n    if (prev === newValue) return;\n    let net = parseInt(netEl.textContent, 10) || 0;\n    // remove previous contribution\n    if (prev === 1) net -= 1;\n    if (prev === -1) net += 1;\n    // add new\n    if (newValue === 1) net += 1;\n    if (newValue === -1) net -= 1;\n    netEl.textContent = net;\n    up.classList.toggle('is-on', newValue === 1);\n    down.classList.toggle('is-on', newValue === -1);\n    up.setAttribute('aria-pressed', String(newValue === 1));\n    down.setAttribute('aria-pressed', String(newValue === -1));\n  }\n\n  // Toggle button state only — no net arithmetic. Used to reflect a vote\n  // that the server already counted (the row's net, freshly rendered from\n  // /api/feed, already includes it) — unlike applyVoteToDom, which is for\n  // a change that hasn't been counted yet.\n  function markVoteState(wrap, value) {\n    const up = wrap.querySelector('.vote__up');\n    const down = wrap.querySelector('.vote__down');\n    up.classList.toggle('is-on', value === 1);\n    down.classList.toggle('is-on', value === -1);\n    up.setAttribute('aria-pressed', String(value === 1));\n    down.setAttribute('aria-pressed', String(value === -1));\n  }\n\n  // Fetch the signed-in viewer's own votes for `ids` via a separate\n  // authenticated call (⚠ never fold this into /api/feed — that response is\n  // shared-cached across every anonymous reader; see src/routes/me.js) and\n  // paint them onto the DOM. Failure just leaves the board at its correct\n  // (unhighlighted) public state — never blocks or breaks rendering.\n  //\n  // `feedGeneratedAt` is the cached feed snapshot's own timestamp. The feed\n  // is edge-cached up to 60s (design §6.3/§6.4 — deliberate, for stability\n  // and cost), so a vote cast inside that window can be NEWER than the net\n  // currently on screen. If so its contribution isn't counted yet and must\n  // be added (applyVoteToDom's delta math); if the vote predates the\n  // snapshot, the net already includes it and only the button should change\n  // (markVoteState) — adding the delta again would double-count.\n  async function syncMyVotes(ids, feedGeneratedAt) {\n    if (!me.loggedIn || !ids.length) return;\n    try {\n      const res = await fetch('/api/me/votes?ids=' + ids.join(','), { headers: { Accept: 'application/json' } });\n      if (!res.ok) return;\n      const data = await res.json();\n      const votes = data.votes || {};\n      document.querySelectorAll('.vote[data-item]').forEach((wrap) => {\n        const id = wrap.dataset.item;\n        const v = votes[id];\n        if (!v) return;\n        if (typeof feedGeneratedAt === 'number' && v.createdAt > feedGeneratedAt) {\n          applyVoteToDom(wrap, v.value);\n        } else {\n          markVoteState(wrap, v.value);\n        }\n      });\n    } catch {\n      // network hiccup — board stays fully usable, just unhighlighted\n    }\n  }\n\n  async function replayPendingIfAny() {\n    const pending = C.takePending();\n    if (!pending || pending.kind !== 'vote') return;\n    if (me.loggedIn) {\n      // loadFeed(true) already awaited syncMyVotes, so the DOM's current\n      // button state is the viewer's PRE-replay vote (whatever it was\n      // before this pending tap) — applyVoteToDom's delta math is only\n      // correct if it reads that as \"prev\". Casting first, then applying,\n      // keeps that ordering intact.\n      const result = await C.vote(pending.itemId, pending.value);\n      if (result.ok) {\n        const wrap = document.querySelector('.vote[data-item=\"' + pending.itemId + '\"]');\n        if (wrap) applyVoteToDom(wrap, pending.value);\n      }\n    }\n    if (pending.scrollTo) {\n      const el = document.getElementById(pending.scrollTo);\n      if (el) el.scrollIntoView({ block: 'center' });\n    }\n  }\n\n  // ---- filter chips ----------------------------------------------------\n  function buildChips() {\n    // Type\n    const typeChips = document.getElementById('type-chips');\n    typeChips.innerHTML = chipBtn('All', state.type === '', 'type', '') +\n      chipBtn('Bugs', state.type === 'bug', 'type', 'bug') +\n      chipBtn('Ideas', state.type === 'idea', 'type', 'idea');\n\n    // Status\n    const statusChips = document.getElementById('status-chips');\n    statusChips.innerHTML =\n      chipBtn('Any status', state.status === '', 'status', '') +\n      chipBtn('Planned', state.status === 'planned', 'status', 'planned') +\n      chipBtn('Shipped', state.status === 'shipped', 'status', 'shipped') +\n      chipBtn('Declined', state.status === 'declined', 'status', 'declined');\n\n    // Area (from taxonomy)\n    const areaChips = document.getElementById('area-chips');\n    let html = chipBtn('All areas', state.area === '', 'area', '');\n    if (taxonomy) {\n      for (const a of taxonomy.areas) {\n        if (a.key === 'other') continue;\n        html += chipBtn(a.label, state.area === a.key, 'area', a.key);\n      }\n    }\n    areaChips.innerHTML = html;\n  }\n  function chipBtn(label, active, dim, val) {\n    return '<button class=\"filter-chip' + (active ? ' is-active' : '') + '\" data-dim=\"' + dim + '\" data-val=\"' + C.esc(val) + '\">' + C.esc(label) + '</button>';\n  }\n\n  function onChipClick(e) {\n    const chip = e.target.closest('.filter-chip');\n    if (!chip) return;\n    state[chip.dataset.dim] = chip.dataset.val;\n    writeStateToUrl();\n    buildChips();\n    loadFeed(true);\n  }\n\n  // ---- init ------------------------------------------------------------\n  let searchTimer = null;\n\n  async function init() {\n    readStateFromUrl();\n    // auth + taxonomy in parallel\n    const [meRes, taxRes] = await Promise.all([\n      C.getMe(),\n      fetch('/data/taxonomy.json').then((r) => r.json()).catch(() => null),\n    ]);\n    me = meRes;\n    taxonomy = taxRes;\n    C.renderAuthSlot(document.getElementById('auth-slot'), me);\n\n    buildChips();\n\n    // sync sort toggle + search input to state\n    document.getElementById('sort-newest').checked = state.sort === 'newest';\n    document.getElementById('search-input').value = state.q;\n\n    await loadFeed(true);\n    await replayPendingIfAny();\n\n    // events\n    document.getElementById('type-chips').addEventListener('click', onChipClick);\n    document.getElementById('status-chips').addEventListener('click', onChipClick);\n    document.getElementById('area-chips').addEventListener('click', onChipClick);\n    document.getElementById('sort-newest').addEventListener('change', (e) => {\n      state.sort = e.target.checked ? 'newest' : 'woven';\n      writeStateToUrl();\n      loadFeed(true);\n    });\n    document.getElementById('search-input').addEventListener('input', (e) => {\n      clearTimeout(searchTimer);\n      const v = e.target.value.trim();\n      searchTimer = setTimeout(() => {\n        state.q = v;\n        writeStateToUrl();\n        loadFeed(true);\n      }, 250);\n    });\n    loadMoreBtn.addEventListener('click', () => {\n      state.page += 1;\n      loadFeed(false);\n    });\n    // event delegation for votes in the woven feed\n    document.querySelector('main').addEventListener('click', handleVoteClick);\n  }\n\n  init();\n})();\n", "/js/item.js": "// The item page (design §6.5): the thread header, the \"N GMs report this\"\n// roll-up of joined reports, the owner note (the only official voice),\n// agree/disagree with login-on-first-tap, and one-level threaded comments.\n\n(function () {\n  const C = window.Care;\n  const root = document.getElementById('item-root');\n  let me = { loggedIn: false };\n  let taxonomy = null;\n  let item = null;\n\n  const itemId = Number(new URLSearchParams(location.search).get('id'));\n\n  function areaLabel(key) {\n    if (!taxonomy) return key;\n    const a = taxonomy.areas.find((x) => x.key === key);\n    if (a) return a.label;\n    if (taxonomy.ideaExtraTile.key === key) return taxonomy.ideaExtraTile.label;\n    return key;\n  }\n\n  function tagStamp(tag) {\n    if (!tag) return '';\n    return '<span class=\"tag tag-' + tag + '\">' + C.TAG_LABEL[tag] + '</span>';\n  }\n  function statusChip(status) {\n    return '<span class=\"chip status-' + status + '\">' + C.STATUS_LABEL[status] + '</span>';\n  }\n\n  function ctxLine(r) {\n    const bits = [];\n    if (r.version) bits.push('v' + r.version);\n    if (r.os) bits.push(cap(r.os));\n    if (r.browser) bits.push(cap(r.browser));\n    return bits.join(' · ');\n  }\n  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }\n\n  function reportBlock(r) {\n    const details = [];\n    if (r.symptom) details.push('<span class=\"rep__sym\">' + C.esc(prettySymptom(r.symptom)) + (r.frequency ? ' · ' + C.esc(prettyFreq(r.frequency)) : '') + '</span>');\n    if (r.expected) details.push('<div class=\"rep__field\"><span class=\"rep__label\">Expected</span> ' + C.esc(r.expected) + '</div>');\n    if (r.actual) details.push('<div class=\"rep__field\"><span class=\"rep__label\">Actual</span> ' + C.esc(r.actual) + '</div>');\n    if (r.ask) details.push('<div class=\"rep__field\"><span class=\"rep__label\">The ask</span> ' + C.esc(r.ask) + '</div>');\n    if (r.why) details.push('<div class=\"rep__field\"><span class=\"rep__label\">Why</span> ' + C.esc(r.why) + '</div>');\n    if (r.doneLooksLike) details.push('<div class=\"rep__field\"><span class=\"rep__label\">Done looks like</span> ' + C.esc(r.doneLooksLike) + '</div>');\n    if (r.importance) details.push('<div class=\"rep__imp\">' + C.esc(prettyImportance(r.importance)) + '</div>');\n    if (r.freetext) details.push('<div class=\"rep__free\">' + C.esc(r.freetext) + '</div>');\n\n    for (const f of r.followups || []) details.push('<div class=\"rep__field\"><span class=\"rep__label\">'+C.esc(f.question)+'</span> '+C.esc(f.answer)+'</div>');\n    const ctx = ctxLine(r);\n    return (\n      '<li class=\"rep\">' +\n      '<div class=\"rep__head\">' +\n      (r.avatar ? '<img class=\"avatar\" src=\"' + C.esc(r.avatar) + '\" alt=\"\" width=\"24\" height=\"24\">' : '<span class=\"avatar avatar--blank\" aria-hidden=\"true\"></span>') +\n      '<span class=\"rep__name\">' + C.esc(r.reporterName) + '</span>' +\n      (ctx ? '<span class=\"rep__ctx mono\">' + C.esc(ctx) + '</span>' : '') +\n      '<span class=\"rep__when\">' + C.relativeTime(r.createdAt) + '</span>' +\n      '</div>' +\n      (details.length ? '<div class=\"rep__details\">' + details.join('') + '</div>' : '') +\n      '</li>'\n    );\n  }\n\n  function commentNode(c) {\n    const replies = (c.replies || []).map((r) =>\n      '<li class=\"cmt cmt--reply\">' + commentInner(r) + '</li>'\n    ).join('');\n    return (\n      '<li class=\"cmt\">' + commentInner(c) +\n      (replies ? '<ul class=\"cmt__replies\">' + replies + '</ul>' : '') +\n      '<button class=\"linkbtn cmt__reply-btn\" data-parent=\"' + c.id + '\">Reply</button>' +\n      '<div class=\"cmt__reply-box\" hidden data-for=\"' + c.id + '\"></div>' +\n      '</li>'\n    );\n  }\n  function commentInner(c) {\n    return (\n      '<div class=\"cmt__head\">' +\n      (c.avatar ? '<img class=\"avatar\" src=\"' + C.esc(c.avatar) + '\" alt=\"\" width=\"22\" height=\"22\">' : '<span class=\"avatar avatar--blank\" aria-hidden=\"true\"></span>') +\n      '<span class=\"cmt__name\">' + C.esc(c.authorName) + '</span>' +\n      '<span class=\"cmt__when\">' + C.relativeTime(c.createdAt) + '</span>' +\n      '</div>' +\n      '<div class=\"cmt__body\">' + C.esc(c.body) + '</div>'\n    );\n  }\n\n  function render() {\n    const gms = item.reportsCount === 1 ? '1 GM reports this' : item.reportsCount + ' GMs report this';\n    const commentsFlat = item.comments || [];\n\n    root.innerHTML =\n      '<article class=\"thread\">' +\n      '<div class=\"thread__top\">' +\n      '<span class=\"thread__serial mono\">#' + item.id + '</span>' +\n      '<div class=\"thread__meta\">' + tagStamp(item.tag) + statusChip(item.status) +\n      '<span class=\"thread__area\">' + C.esc(areaLabel(item.area)) + '</span></div>' +\n      '</div>' +\n      '<h1 class=\"thread__title\">' + C.esc(item.title) + '</h1>' +\n      voteBar() +\n      (item.ownerNote ? ownerNoteBlock() : '') +\n      '<section class=\"rollup\">' +\n      '<h2 class=\"rollup__heading\">' + gms + '</h2>' +\n      '<ul class=\"rollup__list\">' + (item.reports || []).map(reportBlock).join('') + '</ul>' +\n      '</section>' +\n      '<section class=\"comments\">' +\n      '<h2 class=\"comments__heading\">' + (item.commentsCount || 0) + ' ' + (item.commentsCount === 1 ? 'comment' : 'comments') + '</h2>' +\n      (me.loggedIn ? topCommentBox() : '<p class=\"comments__signin\"><button class=\"linkbtn\" id=\"comment-signin\">Sign in to comment</button></p>') +\n      '<ul class=\"comments__list\">' + commentsFlat.map(commentNode).join('') + '</ul>' +\n      '</section>' +\n      '</article>';\n\n    wireEvents();\n  }\n\n  function voteBar() {\n    const mine = item.myVote || 0;\n    return (\n      '<div class=\"votebar\" data-item=\"' + item.id + '\">' +\n      '<button class=\"votebar__btn' + (mine === 1 ? ' is-on is-up' : '') + '\" data-val=\"1\" aria-pressed=\"' + (mine === 1) + '\">▲ Agree</button>' +\n      '<span class=\"votebar__net mono\">' + item.net + '</span>' +\n      '<button class=\"votebar__btn' + (mine === -1 ? ' is-on is-down' : '') + '\" data-val=\"-1\" aria-pressed=\"' + (mine === -1) + '\">▼ Disagree</button>' +\n      '<span class=\"votebar__hint\">Agree pushes it up Hunter’s list.</span>' +\n      '</div>'\n    );\n  }\n  function ownerNoteBlock() {\n    return '<div class=\"ownernote\"><span class=\"ownernote__tag\">From Hunter</span><p>' + C.esc(item.ownerNote) + '</p></div>';\n  }\n  function topCommentBox() {\n    return (\n      '<div class=\"commentbox\">' +\n      '<textarea id=\"new-comment\" class=\"commentbox__input\" rows=\"2\" placeholder=\"Add a comment… (links show as plain text)\" maxlength=\"2000\"></textarea>' +\n      '<button class=\"btn btn-primary\" id=\"post-comment\">Post comment</button>' +\n      '</div>'\n    );\n  }\n\n  // ---- events ----------------------------------------------------------\n  function wireEvents() {\n    const votebar = root.querySelector('.votebar');\n    if (votebar) votebar.addEventListener('click', onVoteClick);\n\n    const signin = document.getElementById('comment-signin');\n    if (signin) signin.addEventListener('click', () => C.login());\n\n    const postBtn = document.getElementById('post-comment');\n    if (postBtn) postBtn.addEventListener('click', () => postComment(null, document.getElementById('new-comment')));\n\n    root.querySelectorAll('.cmt__reply-btn').forEach((btn) => {\n      btn.addEventListener('click', () => toggleReplyBox(Number(btn.dataset.parent)));\n    });\n  }\n\n  async function onVoteClick(e) {\n    const btn = e.target.closest('.votebar__btn');\n    if (!btn) return;\n    const val = Number(btn.dataset.val);\n    if (!me.loggedIn) {\n      C.stashPending({ kind: 'vote', itemId: item.id, value: val });\n      C.login();\n      return;\n    }\n    const wrap = btn.closest('.votebar');\n    if (wrap.dataset.saving==='1') return;\n    wrap.dataset.saving='1';\n    const previous=wrap.querySelector('[data-val=\"1\"]').classList.contains('is-on')?1:wrap.querySelector('[data-val=\"-1\"]').classList.contains('is-on')?-1:0;\n    const currentlyOn = btn.classList.contains('is-on');\n    const newValue = currentlyOn ? 0 : val;\n    applyVote(wrap, newValue);\n    let res;try{res=await C.vote(item.id,newValue);}catch{res={ok:false,status:0,body:{}};}finally{delete wrap.dataset.saving;}\n    if (!res.ok) {\n      applyVote(wrap, previous);\n      if (res.status === 429) alert(res.body.error || 'You have hit today’s limit.');\n    } else if (typeof res.body.net==='number') {wrap.querySelector('.votebar__net').textContent=res.body.net;}\n  }\n  function applyVote(wrap, newValue) {\n    const up = wrap.querySelector('[data-val=\"1\"]');\n    const down = wrap.querySelector('[data-val=\"-1\"]');\n    const netEl = wrap.querySelector('.votebar__net');\n    const prev = up.classList.contains('is-on') ? 1 : down.classList.contains('is-on') ? -1 : 0;\n    if (prev === newValue) return;\n    let net = parseInt(netEl.textContent, 10) || 0;\n    if (prev === 1) net -= 1; if (prev === -1) net += 1;\n    if (newValue === 1) net += 1; if (newValue === -1) net -= 1;\n    netEl.textContent = net;\n    up.classList.toggle('is-on', newValue === 1);\n    up.classList.toggle('is-up', newValue === 1);\n    down.classList.toggle('is-on', newValue === -1);\n    down.classList.toggle('is-down', newValue === -1);\n    up.setAttribute('aria-pressed', String(newValue === 1));\n    down.setAttribute('aria-pressed', String(newValue === -1));\n  }\n\n  function toggleReplyBox(parentId) {\n    const box = root.querySelector('.cmt__reply-box[data-for=\"' + parentId + '\"]');\n    if (!box) return;\n    if (!me.loggedIn) { C.login(); return; }\n    if (box.hidden) {\n      box.hidden = false;\n      box.innerHTML =\n        '<textarea class=\"commentbox__input\" rows=\"2\" placeholder=\"Reply…\" maxlength=\"2000\"></textarea>' +\n        '<button class=\"btn btn-primary btn--sm\">Reply</button>';\n      const btn = box.querySelector('button');\n      btn.addEventListener('click', () => postComment(parentId, box.querySelector('textarea')));\n      box.querySelector('textarea').focus();\n    } else {\n      box.hidden = true;\n      box.innerHTML = '';\n    }\n  }\n\n  async function postComment(parentId, textarea) {\n    const body = (textarea.value || '').trim();\n    if (!body) return;\n    const btn = textarea.parentElement.querySelector('button');\n    if (btn) btn.disabled = true;\n    let res;\n    try { res = await fetch('/api/comment', {\n      method: 'POST',\n      headers: { 'Content-Type': 'application/json' },\n      body: JSON.stringify({ itemId: item.id, body, parentId: parentId || undefined }),\n    });\n    } catch {if(btn)btn.disabled=false;alert('Could not connect. Your comment is still here; please try again.');return;}\n    const data = await res.json().catch(() => ({}));\n    if (!res.ok) {\n      if (btn) btn.disabled = false;\n      alert(data.error || 'Could not post your comment.');\n      return;\n    }\n    // reload the thread to show the new comment (and correct held-state handling server-side)\n    await load();\n  }\n\n  // ---- pretty labels (map contract keys to human text) -----------------\n  function prettySymptom(k) {\n    return ({\n      nothing_happened: 'Nothing happened on click', wrong_thing: 'Did the wrong thing',\n      work_disappeared: 'Work disappeared / didn’t save', display_broken: 'Display looks broken',\n      froze_crashed: 'Froze or crashed', slow: 'Slow', error_message: 'An error appeared',\n      something_else: 'Something else', ai_wrong_answer: 'AI answer was wrong', ai_call_failed: 'AI call failed',\n      wont_import: 'File wouldn’t import', pdf_missing_content: 'PDF missing content', license_wont_activate: 'License won’t activate',\n    })[k] || k;\n  }\n  function prettyFreq(k) { return ({ every_time: 'every time', sometimes: 'sometimes', once: 'happened once' })[k] || k; }\n  function prettyImportance(k) {\n    return ({ nice_to_have: 'Nice to have', every_session: 'Would use every session', cant_run_without: 'Can’t run their game without it' })[k] || k;\n  }\n\n  // ---- load ------------------------------------------------------------\n  // `cache: no-store` so a fresh reload after voting/commenting always shows\n  // the new state, never a stale browser-cached copy (belt-and-suspenders on\n  // top of the server's Vary: Cookie).\n  async function load() {\n    const res = await fetch('/api/item/' + itemId, { headers: { Accept: 'application/json' }, cache: 'no-store' });\n    if (res.status === 409) {\n      const body = await res.json().catch(() => ({}));\n      if (body.mergedInto) { location.replace('/item/?id=' + body.mergedInto); return; }\n    }\n    if (!res.ok) {\n      root.innerHTML = '<div class=\"empty-state\"><h2>That report isn’t here</h2><p>It may have been removed or merged.</p><a class=\"btn btn-primary\" href=\"/\">Back to the board</a></div>';\n      return;\n    }\n    item = await res.json();\n    document.title = '#' + item.id + ' · ' + item.title + ' — RealmWright';\n    render();\n  }\n\n  async function init() {\n    if (!Number.isInteger(itemId)) {\n      root.innerHTML = '<div class=\"empty-state\"><h2>No report selected</h2><a class=\"btn btn-primary\" href=\"/\">Back to the board</a></div>';\n      return;\n    }\n    const [meRes, taxRes] = await Promise.all([\n      C.getMe(),\n      fetch('/data/taxonomy.json').then((r) => r.json()).catch(() => null),\n    ]);\n    me = meRes; taxonomy = taxRes;\n    C.renderAuthSlot(document.getElementById('auth-slot'), me);\n    await load();\n    // replay a pending vote from a pre-login tap\n    const pending = C.takePending();\n    if (pending && pending.kind === 'vote' && me.loggedIn && item) {\n      await C.vote(pending.itemId, pending.value);\n      await load();\n    }\n  }\n\n  init();\n})();\n"};
