import subprocess,json,uuid,tempfile,os,time
from api import api,ROOT,ACCOUNT,DB
ORIGIN='https://realmwright-care.mdnahin537.workers.dev'
fd,cookie=tempfile.mkstemp(prefix='care-qa-cookie-');os.close(fd)
marker='CARE-VERIFY-'+uuid.uuid4().hex
item_id=report_id=None;sub=None

def http(path,body=None,auth=False):
 cmd=['curl','-sS','--max-time','35','-b',cookie,'-c',cookie,'-H','Origin: '+ORIGIN,'-w','\n%{http_code}']
 if body is not None:cmd+=['-X','POST','-H','Content-Type: application/json','--data-binary',json.dumps(body)]
 if auth:cmd+=['-H','X-Care-Action: bootstrap']
 cmd+=[ORIGIN+path];r=subprocess.run(cmd,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr)
 text,status=r.stdout.rsplit('\n',1)
 return int(status),json.loads(text) if text else None

def query(sql):return api(f'accounts/{ACCOUNT}/d1/database/{DB}/query','POST',{'sql':sql})['result']
try:
 status,body=http('/auth/bootstrap',{},True);assert status==200 and body.get('created'),(status,body)
 payload={'type':'bug','area':'exports-data','symptom':'work_disappeared','frequency':'every_time',
  'title':'Connection test '+marker,
  'expected':'The report and a complete email copy are saved together.',
  'actual':'This is an isolated verification, not a customer issue.',
  'freetext':marker+' — buy followers is a moderation test phrase to keep this synthetic report OFF the public board.',
  'ctx':{'v':marker,'schema':7,'build':'test'},'clientCtx':{'os':'android','browser':'chrome'}}
 status,body=http('/api/report',payload);assert status==200,(status,body)
 item_id=body['itemId'];report_id=body['reportId'];assert body.get('held') is True
 rows=query(f"SELECT r.user_sub,r.payload,i.held,o.event_key,o.state FROM reports r JOIN items i ON i.id=r.item_id JOIN care_mail_outbox o ON o.event_key='report:'||r.id WHERE r.id={int(report_id)}")[0]['results']
 assert len(rows)==1;row=rows[0];sub=row['user_sub'];p=json.loads(row['payload']);assert p['ctx']['v']==marker and p['ctx']['schema']==7;assert row['held']==1 and row['state'] in ('pending','sending','accepted')
 print('PASS Live submission saved full details and an email copy together',flush=True)
 for attempt in range(8):
  statusrow=query(f"SELECT state,attempts,last_error FROM care_mail_outbox WHERE event_key='report:{int(report_id)}'")[0]['results'][0]
  if statusrow['state']=='accepted':break
  if statusrow['last_error']:raise AssertionError(statusrow)
  time.sleep(3)
 assert statusrow['state']=='accepted',statusrow
 print('PASS Brevo accepted the full email copy; Gmail receipt is a separate check',flush=True)
 status,_=http('/api/item/'+str(item_id));assert status==404;print('PASS Synthetic verification stayed hidden from the public board')
 status,_=http('/auth/logout');assert status==302
 safe_sub=sub.replace("'","''")
 sessions=query(f"SELECT COUNT(*) AS n FROM care_sessions WHERE user_sub='{safe_sub}' AND revoked_at IS NULL")[0]['results'][0]['n'];assert sessions==0
 print('PASS Live logout invalidated the test session')
 (ROOT/'submission-check.json').write_text(json.dumps({'saved_report_and_copy':True,'full_context_preserved':True,'hidden_from_public':True,'logout_revoked':True,'email_provider_accepted':True,'email_delivered':False,'test_marker':marker,'item_id':item_id,'reason':'Gmail receipt still to verify'},indent=2))
finally:
 if item_id is not None and report_id is not None:
  if sub is None:
   rows=query(f'SELECT user_sub,payload FROM reports WHERE id={int(report_id)}')[0]['results']
   if rows and marker in rows[0]['payload']:sub=rows[0]['user_sub']
  assert sub is not None,'Cannot safely identify test identity for cleanup'
  safe_sub=sub.replace("'","''")
  query(f"DELETE FROM care_mail_outbox WHERE event_key='report:{int(report_id)}'; DELETE FROM votes WHERE item_id={int(item_id)}; DELETE FROM vote_events WHERE item_id={int(item_id)}; DELETE FROM reports WHERE id={int(report_id)}; DELETE FROM items WHERE id={int(item_id)}; DELETE FROM care_sessions WHERE user_sub='{safe_sub}'; DELETE FROM users WHERE sub='{safe_sub}';")
  left=query(f"SELECT (SELECT COUNT(*) FROM items WHERE id={int(item_id)})+(SELECT COUNT(*) FROM users WHERE sub='{safe_sub}')+(SELECT COUNT(*) FROM care_mail_outbox WHERE event_key='report:{int(report_id)}') AS n")[0]['results'][0]['n'];assert left==0
  print('PASS All synthetic submission, copy and identity records removed')
 os.unlink(cookie)
