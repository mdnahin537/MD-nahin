from pathlib import Path
import json
R=Path(__file__).parent
s=(R/'worker-base.mjs').read_text()
s=s.replace('//# sourceMappingURL=index.js.map','')
assets={'/js/wizard.js':(R/'wizard-fixed.js').read_text(),'/js/board.js':(R/'board-fixed.js').read_text(),'/js/item.js':(R/'item-fixed.js').read_text()}
s+='\n'+(R/'notifications.mjs').read_text()+'\nconst CARE_CLIENT_ASSETS='+json.dumps(assets,ensure_ascii=False)+';\n'
(R/'worker.mjs').write_text(s)
print('Built',len(s.encode()),'bytes')
