import subprocess,json,hashlib,concurrent.futures
from pathlib import Path
R=Path(__file__).parent
ORIGIN='https://realmwright-care.mdnahin537.workers.dev'
def fetch(path):
 result=subprocess.run(['curl','-sS','--connect-timeout','10','--max-time','25','-w','\n%{http_code}',ORIGIN+path],capture_output=True,text=True)
 if result.returncode:raise RuntimeError(result.stderr)
 body,code=result.stdout.rsplit('\n',1);return int(code),body
checks=[('/api/health',200,None),('/report/',200,None),('/api/feed',200,None),('/api/desk/summary',404,None),('/desk/',404,None),('/js/wizard.js',200,'wizard-fixed.js'),('/js/board.js',200,'board-fixed.js'),('/js/item.js',200,'item-fixed.js'),('/privacy/',200,None)]
def check(entry):
 path,expected,local=entry;code,body=fetch(path);assert code==expected,(path,code)
 if local:assert body==(R/local).read_text(), 'Deployed JS mismatch: '+local
 if path=='/api/health':assert json.loads(body).get('release')=='2026-09-29-care-repair'
 if path=='/api/feed':assert isinstance(json.loads(body).get('items'),list)
 if path=='/privacy/':assert 'window.__CONTACT_EMAIL__="mdnahin537@gmail.com"' in body
 return {'path':path,'status':code,'passed':True,'source_match':bool(local)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(check,checks))
(R/'live-checks.json').write_text(json.dumps(results,indent=2))
for row in results:print('PASS',row['path'],row['status'],'exact source match' if row['source_match'] else '')
