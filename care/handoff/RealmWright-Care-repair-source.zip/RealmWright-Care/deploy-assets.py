"""Deploy preserved live assets with repaired client scripts; no secrets in output."""
import base64, hashlib, json, mimetypes, pathlib, subprocess, uuid
from api import api, ACCOUNT, ROOT
from upload import upload

prefix = f'accounts/{ACCOUNT}/workers/scripts/realmwright-care'
directory = ROOT / 'assets-fixed'
manifest = {}
files = {}
for path in sorted(directory.rglob('*')):
    if not path.is_file():
        continue
    content = path.read_bytes()
    encoded = base64.b64encode(content)
    digest = hashlib.sha256(encoded + path.suffix[1:].encode()).hexdigest()[:32]
    manifest['/' + path.relative_to(directory).as_posix()] = {'hash': digest, 'size': len(content)}
    files[digest] = (path, encoded)
assert len(manifest) == 20, 'Unexpected asset inventory'
(ROOT / 'asset-manifest.json').write_text(json.dumps(manifest, indent=2))
session = api(prefix + '/assets-upload-session', 'POST', {'manifest': manifest})['result']
token = session['jwt']
completion = token if not session.get('buckets') else None
for bucket in session.get('buckets', []):
    boundary = '----CareAssets' + uuid.uuid4().hex
    parts = []
    for digest in bucket:
        path, encoded = files[digest]
        mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{digest}"; filename="{path.name}"\r\nContent-Type: {mime}\r\n\r\n').encode() + encoded + b'\r\n')
    body = b''.join(parts) + (f'--{boundary}--\r\n').encode()
    response = subprocess.run(['curl', '-sS', '--max-time', '40', '-X', 'POST',
        '-H', 'Authorization: Bearer ' + token, '-H', 'Content-Type: multipart/form-data; boundary=' + boundary,
        '--data-binary', '@-', f'https://api.cloudflare.com/client/v4/accounts/{ACCOUNT}/workers/assets/upload?base64=true'],
        input=body, capture_output=True)
    if response.returncode:
        raise RuntimeError(response.stderr.decode())
    result = json.loads(response.stdout)
    assert result.get('success'), result.get('errors')
    if result.get('result', {}).get('jwt'):
        completion = result['result']['jwt']
    print('Uploaded asset bucket:', len(bucket), flush=True)
assert completion, 'Missing asset completion token'
settings = api(prefix + '/settings')['result']
names = {b['name'] for b in settings['bindings']}
assert {'SESSION_SECRET', 'OWNER_SETUP_TOKEN', 'CARE_MAIL_API_KEY'} <= names
metadata = json.loads((ROOT / 'email-deploy-metadata.json').read_text())
metadata.pop('keep_assets', None)
metadata['bindings'] = [{'name': b['name'], 'type': 'inherit', 'version_id': 'latest'}
    if b['name'] != 'ASSETS' else {'name': 'ASSETS', 'type': 'assets'} for b in settings['bindings']]
metadata['assets'] = {'jwt': completion, 'config': {'html_handling': 'auto-trailing-slash',
    'not_found_handling': '404-page', 'run_worker_first': ['/api/*', '/auth/*', '/desk', '/desk/*', '/privacy', '/privacy/']}}
metadata['annotations'] = {'workers/message': 'Deploy repaired Customer Care forms and full email copies; preserve public pages and owner protection'}
result = upload('realmwright-care', (ROOT / 'worker.mjs').read_text(), metadata)
(ROOT / 'assets-deploy-result.json').write_text(json.dumps(result, indent=2))
after = api(prefix + '/settings')['result']
assert {b['name'] for b in after['bindings']} == names
assert next(b for b in after['bindings'] if b['name'] == 'CARE_MAIL_ENABLED')['text'] == 'true'
print('Repaired assets deployed; all bindings preserved', flush=True)
