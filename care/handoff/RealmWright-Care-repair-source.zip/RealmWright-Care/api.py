import subprocess,json,pathlib,sys
ROOT=pathlib.Path(__file__).parent
ACCOUNT='9455d312bcd801c4d493a579560c7863'
DB='4d9ddc05-5e6f-4a56-b657-31a52ed99209'
def api(path,method='GET',data=None):
 cmd=['curl','-sS','--max-time','45','-X',method,'-H','Authorization: Bearer '+pathlib.Path('/tmp/care-token').read_text().strip()]
 if data is not None:cmd+=['-H','Content-Type: application/json','--data-binary','@-']
 cmd+=['https://api.cloudflare.com/client/v4/'+path]
 r=subprocess.run(cmd,input=json.dumps(data) if data is not None else None,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr)
 out=json.loads(r.stdout)
 if not out.get('success'):raise RuntimeError(json.dumps(out.get('errors')))
 return out
if __name__=='__main__':
 import concurrent.futures
 def get(name,path,data=None):
  v=api(path,'POST' if data else 'GET',data);(ROOT/name).write_text(json.dumps(v,indent=2));print(name,'saved');return v
 with concurrent.futures.ThreadPoolExecutor() as e:
  a=e.submit(get,'version.json',f'accounts/{ACCOUNT}/workers/scripts/realmwright-care/versions/dfacac24-e9c8-4379-be24-40d4c829ebc4')
  b=e.submit(get,'schema.json',f'accounts/{ACCOUNT}/d1/database/{DB}/query',{'sql':"SELECT name,sql FROM sqlite_master WHERE type IN ('table','index') AND name NOT LIKE 'sqlite_%'"})
  print('Asset configuration:',a.result().get('result',{}).get('resources',{}).get('script',{}));b.result()
