const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(__dirname+'/wizard-fixed.js','utf8');
const start=source.indexOf('  async function submitReport(isJoin)');const end=source.indexOf('\n  function showError(',start);
let captured,calls=0;let release;
const state={flow:'bug',area:'exports-data',part:'json',symptom:'work_disappeared',symptomDetail:'after_export',frequency:'every_time',expected:'Everything stays',actual:'Missing scene',freetext:'Original detail',ctx:{v:'vTest'},clientCtx:{os:'android'},joinItemId:17};
const c={state,submitting:false,removedCtx:new Set(),document:{getElementById:()=>null},goTo:()=>{},showError:m=>{throw Error(m)},fetch:async(url,opts)=>{calls++;captured=JSON.parse(opts.body);await new Promise(r=>release=r);return {ok:true,json:async()=>({itemId:17,reportId:22})}}};
vm.createContext(c);vm.runInContext(source.slice(start,end),c);
(async()=>{
 const first=c.submitReport(true);await c.submitReport(true);assert.equal(calls,1);release();await first;
 for(const key of ['symptom','frequency','expected','actual','freetext'])assert.equal(captured[key],state[key]);assert.equal(captured.ctx.v,'vTest');assert.equal(captured.clientCtx.os,'android');assert.equal(captured.joinItemId,17);
 console.log('PASS Actual joined-submission client code preserves all entered details');
 console.log('PASS Double click while saving sends only one request');
 c.state.flow='idea';c.state.ask='Workflow request';c.state.why='Prep faster';c.state.doneLooksLike='One coherent plan';c.state.kind='workflow';c.state.importance='every_session';
 const idea=c.submitReport(false);release();await idea;assert.equal(captured.ask,'Workflow request');assert.equal(captured.why,'Prep faster');assert.equal(captured.doneLooksLike,'One coherent plan');console.log('PASS Actual new-idea client code sends request, reason and success criteria');
 const a=source.indexOf('  async function joinItem(itemId)');const b=source.indexOf('\n  // ---- write',a);let screen='';c.goTo=s=>screen=s;vm.runInContext(source.slice(a,b),c);await c.joinItem(45);assert.equal(screen,'ask');assert.equal(c.state.joinItemId,45);assert.equal(calls,2);console.log('PASS Choosing a matching item opens the detail step before submission');
})().catch(e=>{console.error(e);process.exitCode=1});
