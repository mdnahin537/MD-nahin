const {DatabaseSync}=require('node:sqlite');
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const path=require('path');const ROOT=__dirname;
const sqlDb=new DatabaseSync(':memory:');
const schema=JSON.parse(fs.readFileSync(path.join(ROOT,'schema.json'),'utf8')).result[0].results;
for(const row of schema)if(row.sql)sqlDb.exec(row.sql);
sqlDb.exec(fs.readFileSync(path.join(ROOT,'migration.sql'),'utf8'));
function wrap(sql,args=[]){return {sql,args,bind(...args){return wrap(sql,args)},async first(){return run(sql,args).results[0]||null},async all(){return run(sql,args)},async run(){return run(sql,args)}}}
function run(sql,args){const stmt=sqlDb.prepare(sql);const named=Object.fromEntries(args.map((v,i)=>[String(i+1),v]));const results=stmt.all(named);return {results,meta:{changes:Number(sqlDb.prepare('SELECT changes() AS n').get().n)}}}
const DB={prepare:wrap,async batch(statements){sqlDb.exec('BEGIN');try{const r=statements.map(s=>run(s.sql,s.args));sqlDb.exec('COMMIT');return r;}catch(e){sqlDb.exec('ROLLBACK');throw e}}};
const tax=JSON.parse(fs.readFileSync(path.join(ROOT,'taxonomy.json'),'utf8'));
const context={Request,Response,Headers,URL,TextEncoder,TextDecoder,Uint8Array,AbortSignal,crypto:require('crypto').webcrypto,setTimeout,clearTimeout,console,btoa,atob};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(ROOT,'worker.mjs'),'utf8').replace(/export\s*\{\s*index_default as default\s*\};/,''),context);
const env={DB,ASSETS:{fetch:async()=>new Response(JSON.stringify(tax))},SESSION_SECRET:'only-test-secret',ENVIRONMENT:'production',CARE_MAIL_ENABLED:'false'};
const origin='https://realmwright-care.mdnahin537.workers.dev';
const request=(url,body,method='POST')=>new Request(origin+url,{method,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
let count=0;const pass=s=>{count++;console.log('PASS '+s)};
(async()=>{
 const now=Math.floor(Date.now()/1000);
 sqlDb.prepare("INSERT INTO users(sub,name,created_at,is_owner) VALUES ('test-user','Test GM',?,1)").run(now-200000);
 context.getSession=async()=>({sub:'test-user',isOwner:true,name:'Test GM'});
 let res=await context.handleGetMe(new Request(origin+'/api/me'),env);assert.equal((await res.json()).isOwner,true);pass('Owner is recognized using current identity');
 const area=tax.areas.find(a=>a.key==='exports-data')?.key || tax.areas[0].key;
 const base={type:'bug',area,symptom:'work_disappeared',frequency:'every_time',expected:'Expected α',actual:'Actual β',freetext:'Full details',ctx:{v:'TEST',mode:'campaign'},clientCtx:{os:'android',browser:'chrome'}};
 res=await context.handlePostReport(request('/api/report',base),env,new URL(origin+'/api/report'));
 assert.equal(res.status,200);const first=await res.json();assert.ok(first.itemId);assert.ok(first.reportId);pass('New report is saved with its item in one transaction');
 const initial=sqlDb.prepare('SELECT * FROM care_mail_outbox').all();assert.equal(initial.length,1);assert.equal(JSON.parse(initial[0].snapshot).reportId,first.reportId);pass('Each saved report creates a durable email copy');
 res=await context.handlePostReport(request('/api/report',{...base,mode:'join',joinItemId:first.itemId}),env,new URL(origin+'/api/report'));
 assert.equal(res.status,200);const joined=await res.json();assert.notEqual(joined.reportId,first.reportId);assert.equal(joined.itemId,first.itemId);
 const j=JSON.parse(sqlDb.prepare('SELECT payload FROM reports WHERE id=?').get(joined.reportId).payload);assert.equal(j.frequency,'every_time');assert.equal(j.ctx.os,'android');pass('Joining keeps details and attaches to the same board item');
 await Promise.all([context.castVote(env,first.itemId,'test-user',-1),context.castVote(env,first.itemId,'test-user',-1)]);
 const v=sqlDb.prepare('SELECT * FROM items WHERE id=?').get(first.itemId);assert.equal(v.agree_count,0);assert.equal(v.disagree_count,1);pass('Simultaneous repeated votes cannot inflate counters');
 await context.castVote(env,first.itemId,'test-user',0);assert.equal(sqlDb.prepare('SELECT net FROM items WHERE id=?').get(first.itemId).net,0);pass('Vote removal restores correct count');
 const q=context.detectGaps({...base,expected:'',actual:'',freetext:'',symptom:'slow'})[0];
 // The existing report has exports-data with no specific part, so which_export is offered.
 const gap=context.detectGaps(JSON.parse(sqlDb.prepare('SELECT payload FROM reports WHERE id=?').get(first.reportId).payload))[0];
 assert.ok(gap);
 res=await context.handlePatchFollowup(request('/api/report/'+first.reportId+'/followup',{q:gap.q,a:gap.options[0].key},'PATCH'),env,new URL(origin),first.reportId);assert.equal(res.status,200);
 assert.equal(sqlDb.prepare("SELECT COUNT(*) AS n FROM care_mail_outbox WHERE kind='followup'").get().n,1);pass('Follow-up answer is saved and creates an updated full email copy');
 res=await context.handlePatchFollowup(request('/api/report/'+first.reportId+'/followup',{q:gap.q,a:gap.options[0].key},'PATCH'),env,new URL(origin),first.reportId);assert.equal(res.status,200);assert.equal(sqlDb.prepare("SELECT COUNT(*) AS n FROM care_mail_outbox WHERE kind='followup'").get().n,1);pass('Retrying the same follow-up does not duplicate email events');
 res=await context.handlePostComment(request('/api/comment',{itemId:first.itemId,body:'A complete comment'}),env,new URL(origin));assert.equal(res.status,200);assert.equal(sqlDb.prepare("SELECT COUNT(*) AS n FROM care_mail_outbox WHERE kind='comment'").get().n,1);pass('Comment stays on board and queues a full email copy');
 const item=await (await context.handleGetItem(new Request(origin+'/api/item/'+first.itemId),env,new URL(origin),first.itemId)).json();assert.ok(item.reports[0].followups.length);pass('Saved follow-up details are visible with the public report');
 const evt=sqlDb.prepare("SELECT * FROM care_mail_outbox WHERE kind='followup'").get();const fields=await context.composeCareMail(env,evt);assert.equal(fields.Expected,'Expected α');assert.equal(fields['Device OS'],'android');assert.ok(fields['Follow-up answers'].includes(':'));assert.ok(fields['Original submitted details (complete)'].includes('TEST'));pass('Email contains original text, device details and readable follow-up answers');
 let mailCalls=0;context.deliverCareMail=async()=>{mailCalls++};env.CARE_MAIL_ENABLED='true';await Promise.all([context.drainCareMail(env),context.drainCareMail(env)]);assert.equal(mailCalls,3);pass('Concurrent delivery workers claim each event once');
 context.deliverCareMail=async()=>{throw Error('simulated outage')};await context.drainCareMail(env);const pending=sqlDb.prepare("SELECT * FROM care_mail_outbox WHERE state='pending'").get();assert.ok(pending);assert.equal(pending.attempts,1);assert.ok(pending.next_attempt_at>now);pass('Email outage preserves the report and schedules a retry');
 const ownerToken='test-session';const hash=await context.hmacHex(env.SESSION_SECRET,ownerToken);sqlDb.prepare('INSERT INTO care_sessions(token_hash,user_sub,created_at,last_seen,expires_at) VALUES (?,?,?,?,?)').run(hash,'test-user',now,now,now+3600);
 await context.handleLogout(new Request(origin+'/auth/logout',{headers:{Cookie:'rw_care_session='+ownerToken}}),env,new URL(origin+'/auth/logout'));assert.ok(sqlDb.prepare('SELECT revoked_at FROM care_sessions WHERE token_hash=?').get(hash).revoked_at);pass('Logout revokes the server session');
 res=await context.handlePostReport(request('/api/report',null),env,new URL(origin));assert.equal(res.status,400);pass('Invalid JSON object is rejected clearly');
 res=await context.handlePostReport(request('/api/report',{...base,freetext:'x'.repeat(66000)}),env,new URL(origin));assert.equal(res.status,400);pass('Oversized submissions are bounded');
 // Inject a report-insert failure and prove the item and outbox roll back together.
 const itemCount=sqlDb.prepare('SELECT COUNT(*) AS n FROM items').get().n;
 sqlDb.exec("CREATE TRIGGER fail_test_report BEFORE INSERT ON reports WHEN NEW.payload LIKE '%ROLLBACK_PROBE%' BEGIN SELECT RAISE(ABORT,'test failure'); END;");
 let failed=false;try{await context.handlePostReport(request('/api/report',{...base,freetext:'ROLLBACK_PROBE'}),env,new URL(origin))}catch{failed=true};assert.ok(failed);assert.equal(sqlDb.prepare('SELECT COUNT(*) AS n FROM items').get().n,itemCount);pass('Failed save leaves no empty board item');
 console.log('TOTAL '+count+' checks passed');
})().catch(e=>{console.error(e);process.exitCode=1});
