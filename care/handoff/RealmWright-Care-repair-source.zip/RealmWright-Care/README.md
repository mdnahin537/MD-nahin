# RealmWright Customer Care recovery and source package

Service: https://realmwright-care.mdnahin537.workers.dev/
Source retrieved directly from the deployed Cloudflare Worker on 2026-09-29.
Previous version: dfacac24-e9c8-4379-be24-40d4c829ebc4.

worker.mjs is the repaired deployable Worker. It embeds repaired client JS routes while retaining the existing Cloudflare assets. Original files are included for recovery. Existing secret bindings are inherited; this package contains no secret values.

Changes: matching-report path preserves context and allows details before sending; duplicate clicks suppressed; owner identity fixed; logout revokes server sessions; vote counters recomputed within transactions; actual idea fields included in summaries; JSON request bounds; follow-up validation and conflict protection; public follow-up detail display; database report creation atomic; failed network actions keep input; privacy contact configured.

Email: reports and comments remain stored in Customer Care. Additive D1 triggers capture a complete immutable email-copy event with each report, comment, and follow-up. Delivery uses a fixed owner recipient, HTML-escaped full details, leases, retries and an owner-only queue-status endpoint. CARE_MAIL_ENABLED=true in production. The verified Gmail sender and Brevo API secret are connected. The adapter uses Brevo and requires a verified sender plus CARE_MAIL_API_KEY as a Worker secret. A real isolated submission was saved with its full context; Brevo accepted its full copy, and Gmail received it in the Inbox. Both plain-text and HTML copies contain the complete accepted report. Test records were removed after verification. Brevo's free-address sender replacement is a temporary provider-supported mechanism, not a permanent deliverability guarantee. No domain was purchased. The failed no-account FormSubmit probe is not used in production.

Tests: node test.cjs; node test-client.cjs. Test DB is in-memory SQLite using the live schema. No real customer records are used in local tests. A provider-acceptance response is distinct from Gmail receipt.

Deployment: deploy.py uses /tmp/care-token (not included). It checks the live previous version before writing, applies the additive migration, inherits original bindings, retains assets, uploads worker.mjs, and configures a five-minute retry schedule. Do not run it again without reviewing the current live version. To roll back the Worker, deploy the previous Cloudflare version at 100%; the additional outbox table/triggers are additive and need not be removed to restore the old code.

Sources: Cloudflare Worker Upload API / multipart upload metadata and direct asset upload docs; Brevo transactional email API, sender verification, free-plan and free-address replacement documentation.

Final deployment — 2026-09-30: all 20 static assets were uploaded, preserving live public files and replacing wizard.js, board.js, and item.js with their repaired versions. Owner Desk HTML encoding was corrected using the confirmed Customer Care repository branch. keep_assets preserves the old asset routing configuration, so it cannot alone publish the embedded client-script repairs. The final deployment uses a complete asset manifest and retains the original protected-path routing. All 14 bindings, including existing secrets, are preserved.

Verification: 21 local repair checks passed. Nine live endpoint checks passed; all three repaired scripts exactly match the expected source. The full test email arrived in Gmail Inbox (message 1a0f0f20b005f2d8) with matching original fields, numeric schema, device and browser details. Public test visibility stayed hidden; logout revoked its session; all synthetic Customer Care records were removed. Existing customer data was not deleted. Brevo rewrote the sender to mdnahin537@12302051.brevosend.com; Gmail reported SPF, DKIM and DMARC passes. This is a verified present-day setup, not a guarantee against future provider changes.

Current deploy entry: deploy-assets.py. It uploads assets-fixed using the documented asset API, then uploads worker.mjs and inherits existing secrets. It requires /tmp/care-token and an already-connected CARE_MAIL_API_KEY secret; neither secret value is included. deploy.py is the historical first-deployment script and must not be rerun against the current service.
