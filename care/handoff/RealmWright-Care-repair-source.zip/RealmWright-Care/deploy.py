import json,pathlib,hashlib
from api import api,ACCOUNT,DB,ROOT
from upload import upload
previous=json.loads((ROOT/'deployments.json').read_text())['result']['deployments'][0]['versions'][0]['version_id']
latest=api(f'accounts/{ACCOUNT}/workers/scripts/realmwright-care/deployments')['result']['deployments'][0]['versions']
assert latest==[{'version_id':previous,'percentage':100}], 'Live version changed; refusing to overwrite'
settings=json.loads((ROOT/'settings.json').read_text())['result']
bindings=[{'name':b['name'],'type':'inherit','version_id':'latest'} for b in settings['bindings'] if b['name']!='CONTACT_EMAIL']
bindings += [{'type':'plain_text','name':key,'text':value} for key,value in {
 'CONTACT_EMAIL':'mdnahin537@gmail.com','CARE_MAIL_ENABLED':'false','CARE_MAIL_TO':'mdnahin537@gmail.com','CARE_MAIL_FROM':'mdnahin537@gmail.com'}.items()]
metadata={'main_module':'index.js','compatibility_date':settings['compatibility_date'],'compatibility_flags':settings.get('compatibility_flags',[]),
 'bindings':bindings,'keep_assets':True,'assets':{'config':{'run_worker_first':True}},
 'annotations':{'workers/message':'Customer Care repair: preserve joined details, reliable email-copy queue, owner/session/vote fixes; sending pending sender verification'},
 'logpush':settings.get('logpush',False),'tail_consumers':settings.get('tail_consumers',[]),'tags':settings.get('tags',[])}
(ROOT/'deploy-metadata.json').write_text(json.dumps(metadata,indent=2))
result=api(f'accounts/{ACCOUNT}/d1/database/{DB}/query','POST',{'sql':(ROOT/'migration.sql').read_text()})
(ROOT/'migration-result.json').write_text(json.dumps(result,indent=2));print('Additive email-queue migration applied:',result['success'])
result=upload('realmwright-care',(ROOT/'worker.mjs').read_text(),metadata)
(ROOT/'deploy-result.json').write_text(json.dumps(result,indent=2));print('Worker deployed:',result['success'],result['result'].get('etag'))
print('Source SHA256:',hashlib.sha256((ROOT/'worker.mjs').read_bytes()).hexdigest())
# A five-minute retry trigger is dormant while CARE_MAIL_ENABLED=false.
result=api(f'accounts/{ACCOUNT}/workers/scripts/realmwright-care/schedules','PUT',[{'cron':'*/5 * * * *'}]);print('Retry schedule configured:',result['success'])
# Remove the isolated, failed transport probe.
result=api(f'accounts/{ACCOUNT}/workers/scripts/realmwright-care-mailcheck','DELETE');print('Temporary mail-check Worker removed:',result['success'])
