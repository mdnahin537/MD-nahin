import pathlib,subprocess,json,uuid
from api import ROOT,ACCOUNT

def upload(name,source,metadata,extra=None):
 boundary='----CareUpload'+uuid.uuid4().hex
 parts=[]
 files=[('metadata','metadata.json','application/json',json.dumps(metadata).encode()),('index.js','index.js','application/javascript+module',source.encode())]
 if extra:
  files+=extra
 for field,filename,mime,body in files:
  parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+field+'"; filename="'+filename+'"\r\nContent-Type: '+mime+'\r\n\r\n').encode()+body+b'\r\n')
 data=b''.join(parts)+('--'+boundary+'--\r\n').encode()
 cmd=['curl','-sS','--max-time','60','-X','PUT','-H','Authorization: Bearer '+pathlib.Path('/tmp/care-token').read_text().strip(),'-H','Content-Type: multipart/form-data; boundary='+boundary,'--data-binary','@-','https://api.cloudflare.com/client/v4/accounts/'+ACCOUNT+'/workers/scripts/'+name+'?bindings_inherit=strict']
 r=subprocess.run(cmd,input=data,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr.decode())
 result=json.loads(r.stdout)
 if not result.get('success'):raise RuntimeError(json.dumps(result))
 return result
